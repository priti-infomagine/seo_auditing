"""Tests for RedirectCheckService._analyzed_to_result and _browser_result_to_raw."""
from __future__ import annotations

from urllib.parse import urljoin

from app.modules.crawler.services.site_discovery_service import (
    RobotsTxtEvidence,
    SiteDiscoveryResult,
)
from app.modules.seprate_checks.bulk_status.schema import (
    RedirectHeader,
    RedirectHop as BulkRedirectHop,
    RedirectResult,
)
from app.modules.seprate_checks.redirect_check.resolver import ResolveContext
from app.modules.seprate_checks.redirect_check.service import RedirectCheckService


def _minimal_site_discovery() -> SiteDiscoveryResult:
    return SiteDiscoveryResult(
        robots=RobotsTxtEvidence(
            url="https://example.com/robots.txt",
            exists=True,
            content="User-agent: *\nDisallow: /admin/\nSitemap: https://example.com/sitemap.xml\n",
        ),
    )


def _make_context() -> ResolveContext:
    return ResolveContext(
        site_discovery=_minimal_site_discovery(),
        sitemap_url_set={"https://example.com/old-path", "https://example.com/about"},
        url_to_seo={
            "https://example.com/old-path": {
                "title": "Old Page",
                "canonical": "https://example.com/new-path",
                "page_metadata": {
                    "meta_refresh": "5;url=https://example.com/newest",
                },
            },
        },
        url_to_sources={
            "https://example.com/old-path": ["https://example.com/"],
            "https://example.com/new-path": ["https://example.com/", "https://example.com/sidebar"],
        },
        robot_parser=None,
        domain="example.com",
    )


def _minimal_context() -> ResolveContext:
    return ResolveContext(
        site_discovery=_minimal_site_discovery(),
        domain="example.com",
    )


def _fetch_chain_hop(url, status, loc=None, headers=None, meta_refresh=False):
    return {
        "url": url,
        "status": status,
        "location": loc,
        "resolved": urljoin(url, loc) if loc else None,
        "latency_ms": 10,
        "headers": headers or {"content-type": "text/html"},
        **({"meta_refresh": True} if meta_refresh else {}),
    }


class TestAnalyzedToResult:
    """Tests for _analyzed_to_result: analyze_result output → RedirectUrlResult."""

    def test_converts_single_redirect(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        analyzed = analyze_result({
            "url": "https://example.com/old",
            "hops": [
                _fetch_chain_hop("https://example.com/old", 301, "/new"),
                _fetch_chain_hop("https://example.com/new", 200),
            ],
            "error": None,
            "error_type": None,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result("https://example.com/old", analyzed, context)

        assert result.url == "https://example.com/old"
        assert result.is_redirect is True
        assert result.redirect_count == 1
        assert result.final_url == "https://example.com/new"
        assert result.final_status == 200

    def test_converts_ok_no_redirect(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        analyzed = analyze_result({
            "url": "https://example.com/page",
            "hops": [_fetch_chain_hop("https://example.com/page", 200)],
            "error": None,
            "error_type": None,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result("https://example.com/page", analyzed, context)

        assert result.is_redirect is False
        assert result.redirect_count == 0
        assert result.is_broken is False

    def test_converts_broken_link(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        analyzed = analyze_result({
            "url": "https://example.com/gone",
            "hops": [_fetch_chain_hop("https://example.com/gone", 404)],
            "error": None,
            "error_type": None,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result("https://example.com/gone", analyzed, context)

        assert result.is_broken is True
        assert result.final_status == 404

    def test_converts_unreachable(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        analyzed = analyze_result({
            "url": "https://example.com/dead",
            "hops": [],
            "error": "Connection refused",
            "error_type": "connection_refused",
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result("https://example.com/dead", analyzed, context)

        assert result.error is not None
        assert result.is_broken is True

    def test_converts_redirect_loop(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        hops = [
            _fetch_chain_hop("https://example.com/a", 301, "/b"),
            _fetch_chain_hop("https://example.com/b", 301, "/a"),
        ]
        analyzed = analyze_result({
            "url": "https://example.com/a",
            "hops": hops,
            "error": None,
            "error_type": None,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result("https://example.com/a", analyzed, context)

        assert result.is_broken is True

    def test_headers_flat_dict_to_list_of_dicts(self):
        """Critical: fetch_chain stores headers as flat dict, RedirectHop expects list[dict]."""
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        hop = {
            "url": "https://example.com/old",
            "status": 301,
            "location": "/new",
            "resolved": "https://example.com/new",
            "latency_ms": 50,
            "headers": {"content-type": "text/html", "location": "/new", "server": "nginx"},
        }
        analyzed = analyze_result({
            "url": "https://example.com/old",
            "hops": [hop],
            "error": None,
            "error_type": None,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result("https://example.com/old", analyzed, context)

        assert len(result.hops) == 1
        hop_result = result.hops[0]
        assert hop_result.url == "https://example.com/old"
        assert hop_result.status == 301
        assert hop_result.location == "/new"
        assert hop_result.resolved == "https://example.com/new"
        assert hop_result.latency_ms == 50
        assert isinstance(hop_result.headers, list)
        assert len(hop_result.headers) == 3
        header_names = {h["name"] for h in hop_result.headers}
        assert "content-type" in header_names
        assert "location" in header_names
        assert "server" in header_names

    def test_headers_list_passthrough(self):
        """If headers already in list[dict] format, pass through unchanged."""
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        hop = {
            "url": "https://example.com/old",
            "status": 301,
            "location": "/new",
            "resolved": "https://example.com/new",
            "latency_ms": 50,
            "headers": [{"name": "content-type", "value": "text/html"}],
        }
        analyzed = analyze_result({
            "url": "https://example.com/old",
            "hops": [hop],
            "error": None,
            "error_type": None,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result("https://example.com/old", analyzed, context)

        assert len(result.hops[0].headers) == 1
        assert result.hops[0].headers[0] == {"name": "content-type", "value": "text/html"}

    def test_seo_enrichment_canonical(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        context = _make_context()
        analyzed = analyze_result({
            "url": "https://example.com/old-path",
            "hops": [_fetch_chain_hop("https://example.com/old-path", 200)],
            "error": None,
            "error_type": None,
            "source_pages": [],
        })
        result = RedirectCheckService._analyzed_to_result(
            "https://example.com/old-path", analyzed, context
        )

        assert result.canonical == "https://example.com/new-path"

    def test_seo_enrichment_meta_refresh(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        context = _make_context()
        analyzed = analyze_result({
            "url": "https://example.com/old-path",
            "hops": [_fetch_chain_hop("https://example.com/old-path", 200)],
            "error": None,
            "error_type": None,
            "source_pages": [],
        })
        result = RedirectCheckService._analyzed_to_result(
            "https://example.com/old-path", analyzed, context
        )

        assert result.meta_refresh == "5;url=https://example.com/newest"

    def test_meta_refresh_detected_from_hop(self):
        """When fetch_chain detects meta_refresh on a hop, set result.meta_refresh."""
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        hop = _fetch_chain_hop("https://example.com/refresh", 200, meta_refresh=True)
        analyzed = analyze_result({
            "url": "https://example.com/refresh",
            "hops": [hop],
            "error": None,
            "error_type": None,
            "source_pages": [],
            "meta_refresh": True,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result(
            "https://example.com/refresh", analyzed, context
        )

        assert result.meta_refresh == "detected"

    def test_in_sitemap_and_source_pages(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        context = _make_context()
        analyzed = analyze_result({
            "url": "https://example.com/old-path",
            "hops": [_fetch_chain_hop("https://example.com/old-path", 200)],
            "error": None,
            "error_type": None,
            "source_pages": ["https://example.com/"],
        })
        result = RedirectCheckService._analyzed_to_result(
            "https://example.com/old-path", analyzed, context
        )

        assert result.in_sitemap is True
        assert "https://example.com/" in result.source_pages

    def test_robot_allowed_default_true(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        context = _minimal_context()
        analyzed = analyze_result({
            "url": "https://example.com/page",
            "hops": [_fetch_chain_hop("https://example.com/page", 200)],
            "error": None,
            "error_type": None,
        })
        result = RedirectCheckService._analyzed_to_result("https://example.com/page", analyzed, context)

        assert result.robots_allowed is True

    def test_external_redirect_classification(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        analyzed = analyze_result({
            "url": "https://example.com/redirect",
            "hops": [
                _fetch_chain_hop("https://example.com/redirect", 302, "https://other.com/x"),
                _fetch_chain_hop("https://other.com/x", 200),
            ],
            "error": None,
            "error_type": None,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result(
            "https://example.com/redirect", analyzed, context
        )

        assert result.is_external_redirect is True

    def test_too_many_redirects(self):
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        hops = [_fetch_chain_hop(f"https://example.com/r{i}", 301, f"/r{i+1}") for i in range(5)]
        analyzed = analyze_result({
            "url": "https://example.com/r0",
            "hops": hops,
            "error": None,
            "error_type": None,
        })
        context = _minimal_context()
        result = RedirectCheckService._analyzed_to_result("https://example.com/r0", analyzed, context)

        assert result.is_broken is True


class TestBrowserResultToRaw:
    """Tests for _browser_result_to_raw: RedirectResult → raw dict for analyze_result."""

    def test_converts_basic_redirect_result(self):
        bulk_hops = [
            BulkRedirectHop(
                url="https://example.com/old",
                status=301,
                statusText="Moved Permanently",
                location="/new",
                resolved="https://example.com/new",
                latencyMs=50,
                headers=[RedirectHeader(name="location", value="/new", ok=True)],
            ),
            BulkRedirectHop(
                url="https://example.com/new",
                status=200,
                statusText="OK",
                headers=[],
            ),
        ]
        result = RedirectResult(
            input="https://example.com/old",
            hops=bulk_hops,
            redirects=1,
            finalUrl="https://example.com/new",
            finalStatus=200,
            error=None,
        )

        raw = RedirectCheckService._browser_result_to_raw("https://example.com/old", result)

        assert raw["url"] == "https://example.com/old"
        assert raw["error"] is None
        assert raw["error_type"] is None
        assert len(raw["hops"]) == 2
        assert raw["hops"][0]["url"] == "https://example.com/old"
        assert raw["hops"][0]["status"] == 301
        assert raw["hops"][0]["statusText"] == "Moved Permanently"
        assert raw["hops"][0]["location"] == "/new"
        assert raw["hops"][0]["resolved"] == "https://example.com/new"
        assert raw["hops"][0]["latency_ms"] == 50
        # headers should be flat dict
        assert isinstance(raw["hops"][0]["headers"], dict)
        assert raw["hops"][0]["headers"]["location"] == "/new"

    def test_converts_error_result(self):
        result = RedirectResult(
            input="https://example.com/broken",
            hops=[],
            redirects=0,
            finalUrl="https://example.com/broken",
            finalStatus=None,
            error="Browser navigation failed.",
        )

        raw = RedirectCheckService._browser_result_to_raw("https://example.com/broken", result)

        assert raw["error"] == "Browser navigation failed."
        assert raw["error_type"] == "browser_error"
        assert raw["hops"] == []

    def test_result_can_be_fed_to_analyze_result(self):
        """Verify the browser-converted raw dict is compatible with analyze_result."""
        from app.modules.seprate_checks.redirect_check.redirect_report import analyze_result

        bulk_hops = [
            BulkRedirectHop(
                url="https://example.com/old",
                status=301,
                statusText="Moved",
                location="/new",
                resolved="https://example.com/new",
                latencyMs=30,
                headers=[RedirectHeader(name="location", value="/new", ok=True)],
            ),
            BulkRedirectHop(
                url="https://example.com/new",
                status=200,
                statusText="OK",
                headers=[],
            ),
        ]
        result = RedirectResult(
            input="https://example.com/old",
            hops=bulk_hops,
            redirects=1,
            finalUrl="https://example.com/new",
            finalStatus=200,
            error=None,
        )

        raw = RedirectCheckService._browser_result_to_raw("https://example.com/old", result)
        analyzed = analyze_result(raw)

        assert analyzed["state"] == "redirected"
        assert analyzed["redirect_count"] == 1
        assert analyzed["final_url"] == "https://example.com/new"
        assert analyzed["final_status"] == 200
