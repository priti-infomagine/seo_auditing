"""Standalone redirect-chain analysis module.

Provides a single-source-of-truth redirect checking engine with:
  - fetch_chain():       HTTP fetching that never auto-follows redirects,
                         records every hop, classifies errors by exception type.
  - analyze_result():    Classifies each URL into exactly one state
                         (ok | redirected | broken | unreachable | loop | too_many_redirects),
                         so summary counts can never contradict each other.
  - build_findings():    Generates findings with specific error classification,
                         real fix text, and correct where_to_fix.
  - probe_soft_404():    Optional probe for catch-all SPA servers.
  - build_report():      Assembles the full report dict.
  - run_check():         Orchestrates the above for a list of URLs.

Designed to be wired into the existing redirect_check pipeline
(celery task → service._execute → SSE → DB persistence).
"""
from __future__ import annotations

import asyncio
import socket
import ssl
import time
import uuid
from datetime import datetime, timezone
from urllib.parse import urljoin, urlsplit

import httpx
import re

REDIRECT_CODES = {301, 302, 303, 307, 308}
TEMPORARY_CODES = {302, 303, 307}
SEV_RANK = {"low": 1, "medium": 2, "high": 3}
_MAX_HTML_SNIFF_BYTES = 1_000_000
_FALLBACK_PATTERN = re.compile(
    r"<meta[^>]+http-equiv\s*=\s*['\"]?refresh|"
    r"(?:window\s*\.\s*)?location\s*=|"
    r"(?:window\s*\.\s*)?location\s*\.\s*(?:href|replace|assign)\s*=|"
    r"(?:window\s*\.\s*)?location\s*\.\s*(?:replace|assign)\s*\(",
    re.IGNORECASE,
)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def host_of(url: str) -> str:
    host = (urlsplit(url).hostname or "").lower().rstrip(".")
    return host[4:] if host.startswith("www.") else host


def classify_error(exc: BaseException) -> str:
    """Walk the exception chain and return a specific error type."""
    chain, e = [], exc
    while e is not None and e not in chain:
        chain.append(e)
        e = e.__cause__ or e.__context__
    for e in chain:
        name = type(e).__name__
        if isinstance(e, socket.gaierror):
            return "dns_failure"
        if isinstance(e, ssl.SSLError):
            return "tls_error"
        if isinstance(e, ConnectionRefusedError):
            return "connection_refused"
        if isinstance(e, TimeoutError) or "Timeout" in name:
            return "timeout"
        if name == "TooManyRedirects":
            return "too_many_redirects"
    return "connection_failed"


# --------------------------------------------------------------------------
# fetching (httpx). Never auto-follow, record every hop.
# --------------------------------------------------------------------------
async def fetch_chain(client: httpx.AsyncClient, url: str, max_hops: int = 10) -> dict:
    hops, seen, current = [], set(), url
    try:
        for _ in range(max_hops):
            if current in seen:
                break
            seen.add(current)
            t0 = time.perf_counter()
            r = await client.get(current, follow_redirects=False)
            ms = int((time.perf_counter() - t0) * 1000)
            loc = r.headers.get("location")
            is_redirect = r.status_code in REDIRECT_CODES
            hop = {
                "url": current,
                "status": r.status_code,
                "location": loc,
                "resolved": urljoin(current, loc) if loc else None,
                "latency_ms": ms,
                "headers": dict(r.headers),
            }
            # Detect client-side meta-refresh / JS redirect in 200 HTML responses
            ct = r.headers.get("content-type", "").lower()
            if r.status_code == 200 and ("text/html" in ct or "application/xhtml+xml" in ct):
                try:
                    if _FALLBACK_PATTERN.search(r.text):
                        hop["meta_refresh"] = True
                except Exception:
                    pass
            hops.append(hop)
            if is_redirect and loc:
                current = hops[-1]["resolved"]
                continue
            break
    except Exception as exc:  # noqa: BLE001
        return {"url": url, "hops": hops,
                "error": str(exc) or type(exc).__name__,
                "error_type": classify_error(exc)}
    return {"url": url, "hops": hops, "error": None, "error_type": None}


# --------------------------------------------------------------------------
# analysis of ONE url
# --------------------------------------------------------------------------
def analyze_result(raw: dict) -> dict:
    start = raw["url"]
    hops = raw.get("hops") or []
    error, error_type = raw.get("error"), raw.get("error_type")

    redirect_hops = [h for h in hops
                     if h["status"] in REDIRECT_CODES and h.get("location")]
    last = hops[-1] if hops else None
    ends_in_redirect = bool(last and last in redirect_hops)

    if ends_in_redirect:
        target = last.get("resolved") or urljoin(last["url"], last["location"])
        loop = target in [h["url"] for h in hops]
    else:
        loop = False

    # final status/url only exist if the chain ended in a real response
    if error or ends_in_redirect or not last:
        final_status, final_url = None, None
    else:
        final_status, final_url = last["status"], last["url"]

    if error or not hops:
        state = "unreachable"
    elif loop:
        state = "loop"
    elif ends_in_redirect:
        state = "too_many_redirects"
    elif final_status >= 400:
        state = "broken"
    elif redirect_hops:
        state = "redirected"
    else:
        state = "ok"

    redirect_count = len(redirect_hops)
    host_changed = bool(final_url) and host_of(final_url) != host_of(start)
    is_redirect = redirect_count > 0
    downgraded = (urlsplit(start).scheme == "https" and bool(final_url)
                  and urlsplit(final_url).scheme == "http")

    return {
        **raw,
        "state": state,
        "error_type": error_type or ("no_response" if state == "unreachable" else None),
        "redirects": redirect_count,
        "redirect_count": redirect_count,
        "final_url": final_url,
        "finalUrl": final_url,
        "final_status": final_status,
        "finalStatus": final_status,
        "is_redirect": is_redirect,
        "is_internal_redirect": is_redirect and bool(final_url) and not host_changed,
        "is_external_redirect": is_redirect and host_changed,
        "is_loop": loop,
        "is_broken": state in {"broken", "unreachable", "loop", "too_many_redirects"},
        "first_redirect_status": redirect_hops[0]["status"] if redirect_hops else None,
        "insecure": downgraded,
        "chain": [{"url": h["url"], "status": h["status"],
                   "location": h.get("location"), "resolved": h.get("resolved"),
                   "latency_ms": h.get("latency_ms")} for h in hops],
    }


# --------------------------------------------------------------------------
# findings for ONE analyzed url
# --------------------------------------------------------------------------
_ERROR_ADVICE = {
    "dns_failure": ("DNS lookup failed (domain does not resolve).",
                    "Check the domain is registered and has A/AAAA/CNAME records.",
                    "dns_or_domain_registration"),
    "connection_refused": ("Connection refused by the server.",
                           "Make sure the web server listens on 80/443 and the firewall allows it.",
                           "server_or_firewall"),
    "timeout": ("Request timed out.",
                "Check server load, firewall rules and network path to the host.",
                "server_or_network"),
    "tls_error": ("TLS/SSL handshake failed.",
                  "Install a valid certificate that covers this hostname and is not expired.",
                  "ssl_certificate"),
    "too_many_redirects": ("Redirect limit exceeded.",
                           "Flatten the chain so the URL reaches its target in one hop.",
                           "redirect_rules"),
    "connection_failed": ("Could not connect for an unknown reason.",
                          "Retry and inspect the raw exception for the real cause.",
                          "server_or_network"),
    "no_response": ("No response was received.",
                    "Retry and inspect the raw exception for the real cause.",
                    "server_or_network"),
}


def build_findings(r: dict) -> list[dict]:
    url, out = r["url"], []

    def add(code, severity, message, evidence, fix, where):
        out.append({"code": code, "severity": severity, "status":
                    "fail" if severity == "high" else "warning",
                    "message": message, "evidence": evidence, "target_url": url,
                    "redirect_count": r["redirect_count"],
                    "final_status": r["final_status"],
                    "recommendation": {"fix": fix, "where_to_fix": where}})

    state = r["state"]
    if state == "unreachable":
        etype = r["error_type"]
        what, fix, where = _ERROR_ADVICE.get(etype, _ERROR_ADVICE["connection_failed"])
        add(etype if etype in _ERROR_ADVICE else "unreachable", "high",
            f"URL is unreachable: {url}", f"{what} ({r.get('error')})", fix, where)
    elif state == "loop":
        add("redirect_loop", "high", f"Redirect loop starting at {url}",
            " -> ".join([h["url"] for h in r["chain"]] + [r["chain"][-1]["resolved"]]),
            "Remove or correct the rule that sends the URL back into the chain.",
            "redirect_rules")
    elif state == "too_many_redirects":
        add("too_many_redirects", "high", f"Too many redirects from {url}",
            f"{r['redirect_count']} hops without a final response",
            "Flatten the chain so the URL reaches its target in one hop.",
            "redirect_rules")
    elif state == "broken":
        fs = r["final_status"]
        add("broken_link", "high",
            f"URL ends in HTTP {fs}: {url}",
            f"final status {fs} at {r['final_url']}",
            "Restore the page, or 301 it to the best replacement, and update links to it.",
            "source_pages" if r.get("source_pages") else "server_config")

    if r["redirect_count"] > 1 and state in {"redirected", "broken"}:
        add("redirect_chain", "medium", f"Redirect chain ({r['redirect_count']} hops) for {url}",
            " -> ".join([h["url"] for h in r["chain"]]),
            f"Redirect {url} straight to {r['final_url'] or r['chain'][-1]['url']} in one hop.",
            "redirect_rules")

    if r["first_redirect_status"] in TEMPORARY_CODES:
        add("temporary_redirect", "low",
            f"Temporary redirect ({r['first_redirect_status']}) for {url}",
            f"first hop status {r['first_redirect_status']}",
            "If the move is permanent, use 301 (or 308 to keep the HTTP method).",
            "redirect_rules")

    if r["is_internal_redirect"] and r["redirect_count"] == 1 and r.get("source_pages"):
        add("redirect_internal", "low", f"Internal links point to a redirecting URL: {url}",
            f"{url} -> {r['final_url']}",
            f"Update internal links to {r['final_url']} to save a hop.",
            "source_pages")

    if r["is_external_redirect"]:
        add("redirect_external", "low", f"Redirect leaves the host for {url}",
            f"{host_of(url)} -> {host_of(r['final_url'])}",
            "Confirm the host change is intended; update links to the final URL.",
            "source_pages" if r.get("source_pages") else "redirect_rules")

    if r["insecure"]:
        add("https_downgrade", "medium", f"HTTPS downgraded to HTTP for {url}",
            f"{url} -> {r['final_url']}",
            "Redirect to the https:// version of the target.", "redirect_rules")

    return out


# --------------------------------------------------------------------------
# optional: soft-404 probe (catch-all SPA / wrong server config)
# --------------------------------------------------------------------------
async def probe_soft_404(client: httpx.AsyncClient, base_url: str) -> list[dict]:
    fake = urljoin(base_url, f"/{uuid.uuid4().hex}-not-found")
    r = await client.get(fake, follow_redirects=False)
    if r.status_code == 200:
        return [{
            "code": "soft_404", "severity": "medium", "status": "warning",
            "message": "Server returns 200 for a URL that cannot exist",
            "evidence": f"{fake} -> 200 (content-length {r.headers.get('content-length')}, "
                        f"etag {r.headers.get('etag')})",
            "target_url": fake, "redirect_count": 0, "final_status": 200,
            "recommendation": {"fix": "Return a real 404 for unknown routes (server rewrite rules "
                                "or SPA server-side route validation).",
                                "where_to_fix": "server_config"}}]
    return []


# --------------------------------------------------------------------------
# full report
# --------------------------------------------------------------------------
def build_report(domain: str, raw_results: list[dict],
                 extra_findings: list[dict] | None = None) -> dict:
    results = [analyze_result(r) for r in raw_results]
    findings = [f for r in results for f in build_findings(r)] + (extra_findings or [])

    states = [r["state"] for r in results]
    summary = {
        "total_urls": len(results),
        "redirects_found": sum(r["is_redirect"] for r in results),
        "redirect_chains": sum(r["redirect_count"] > 1 and r["state"] == "redirected"
                               for r in results),
        "broken": sum(s in {"broken", "unreachable", "loop", "too_many_redirects"} for s in states),
        "internal_redirects": sum(r["is_internal_redirect"] for r in results),
        "external_redirects": sum(r["is_external_redirect"] for r in results),
        "loops": sum(r["is_loop"] for r in results),
        "meta_refresh": sum(bool(r.get("meta_refresh")) for r in results),
        "insecure": sum(r["insecure"] for r in results),
        "by_status_class": {
            "ok": states.count("ok"),
            "redirect": states.count("redirected"),
            "broken": sum(s in {"broken", "loop", "too_many_redirects"} for s in states),
            "unreachable": states.count("unreachable"),
        },
    }

    # one recommendation per code, with how many URLs are affected
    recs: dict[str, dict] = {}
    for f in findings:
        rec_data = f.get("recommendation", {})
        rec = recs.setdefault(f["code"], {
            "code": f["code"], "priority": f["severity"],
            "title": f["message"].split(":")[0],
            "fix": rec_data.get("fix", ""),
            "where_to_fix": rec_data.get("where_to_fix", "server_config"),
            "affected_count": 0, "examples": []})
        rec["affected_count"] += 1
        if len(rec["examples"]) < 3:
            rec["examples"].append(f["evidence"])

    top = max((SEV_RANK[f["severity"]] for f in findings), default=0)
    severity = {0: "none", 1: "low", 2: "medium", 3: "high"}[top]
    overall = "ok" if top == 0 else ("warning" if top < 3 else "fail")

    return {
        "check_id": str(uuid.uuid4()),
        "domain": domain,
        "status": "completed",
        "total_checked": len(results),
        "results": results,
        "findings": findings,
        "recommendations": sorted(recs.values(), key=lambda x: -SEV_RANK[x["priority"]]),
        "summary": summary,
        "overall_status": overall,
        "severity": severity,
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }


async def run_check(client: httpx.AsyncClient, domain: str, urls: list[str], soft_404: bool = True) -> dict:
    sem = asyncio.Semaphore(10)

    async def one(u):
        async with sem:
            return await fetch_chain(client, u)

    raw = await asyncio.gather(*(one(u) for u in urls))
    extra = await probe_soft_404(client, f"https://{domain}/") if soft_404 else []
    return build_report(domain, list(raw), extra)


# --------------------------------------------------------------------------
# self-test with the cases from your two reports + extras
# --------------------------------------------------------------------------
def _hop(url, status, loc=None):
    return {"url": url, "status": status, "location": loc,
            "resolved": urljoin(url, loc) if loc else None, "latency_ms": 10}


if __name__ == "__main__":
    B = "https://site.com"
    cases = [
        # 1. infomagine case: single 200 hop -> NOT a redirect
        {"url": f"{B}/portfolio", "hops": [_hop(f"{B}/portfolio", 200)],
         "error": None, "error_type": None, "source_pages": [B + "/"]},
        # 2. unreachable domain (your xyz-test-123.in case)
        {"url": "https://xyz-test-123.in/", "hops": [],
         "error": "Connection failed.", "error_type": "dns_failure"},
        # 3. chain 301 -> 301 -> 200
        {"url": f"{B}/a", "hops": [_hop(f"{B}/a", 301, "/b"), _hop(f"{B}/b", 301, "/c"),
                                   _hop(f"{B}/c", 200)], "error": None, "error_type": None},
        # 4. temporary + external
        {"url": f"{B}/x", "hops": [_hop(f"{B}/x", 302, "https://other.com/x"),
                                   _hop("https://other.com/x", 200)],
         "error": None, "error_type": None},
        # 5. loop
        {"url": f"{B}/l1", "hops": [_hop(f"{B}/l1", 301, "/l2"), _hop(f"{B}/l2", 301, "/l1")],
         "error": None, "error_type": None},
        # 6. broken 404
        {"url": f"{B}/gone", "hops": [_hop(f"{B}/gone", 404)], "error": None,
         "error_type": None, "source_pages": [B + "/"]},
    ]
    rep = build_report("site.com", cases)
    states = [r["state"] for r in rep["results"]]
    assert states == ["ok", "unreachable", "redirected", "redirected", "loop", "broken"], states
    assert rep["results"][0]["redirect_count"] == 0 and not rep["results"][0]["is_redirect"]
    assert rep["results"][1]["final_url"] is None
    assert rep["results"][2]["redirect_count"] == 2
    assert rep["results"][3]["is_external_redirect"]
    s = rep["summary"]
    assert s["by_status_class"] == {"ok": 1, "redirect": 2, "broken": 2, "unreachable": 1}, s
    assert s["broken"] == 3 and s["loops"] == 1 and s["redirect_chains"] == 1
    assert rep["overall_status"] == "fail"
    codes = sorted({f["code"] for f in rep["findings"]})
    print("states  :", states)
    print("summary :", s)
    print("findings:", codes)
    print("ALL TESTS PASSED")
