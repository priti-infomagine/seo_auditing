from fastapi import FastAPI
from models import OrganizationSchema, ArticleSchema

app = FastAPI(title="SEO Audit & Schema Tool API")

@app.post("/api/schema/generate/organization")
async def generate_organization_schema(data: OrganizationSchema):
    # Formats the data directly into valid JSON-LD
    schema_json = {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": data.name,
        "url": str(data.url),
        "logo": str(data.logo),
    }
    if data.sameAs:
        schema_json["sameAs"] = [str(url) for url in data.sameAs]
        
    return {"status": "success", "json_ld": schema_json}

@app.post("/api/schema/generate/article")
async def generate_article_schema(data: ArticleSchema):
    schema_json = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": data.title,
        "image": str(data.imageUrl),
        "datePublished": data.datePublished,
        "author": {
            "@type": "Person",
            "name": data.authorName
        },
        "publisher": {
            "@type": "Organization",
            "name": data.publisherName,
            "logo": {
                "@type": "ImageObject",
                "url": str(data.publisherLogo)
            }
        }
    }
    return {"status": "success", "json_ld": schema_json}
