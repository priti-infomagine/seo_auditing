"""Standalone link analysis check DB models.

Architecture:
- ``LinkAnalysisCheck`` — the task master row (one per job). Holds scalar
  aggregate columns + JSONB columns for the full result set.
- ``LinkFinding`` — the per-link findings table. Each row records a single
  discovered link (internal or external) with its HTTP status, source page,
  anchor text, rel flags, and classification.

The DB stores the completed results.  Redis is used for **status / progress**
polling during async task execution (ephemeral — populated by the Celery
worker and read by the API router via ``GET /status/{check_id}``).
"""
import enum
import uuid

from sqlalchemy import (
    Boolean,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    SmallInteger,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base, TimestampMixin


class LinkAnalysisCheckStatus(str, enum.Enum):
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class LinkAnalysisOverallStatus(str, enum.Enum):
    PASS = "pass"
    WARNING = "warning"
    FAIL = "fail"
    NOT_APPLICABLE = "not_applicable"


class LinkAnalysisSeverity(str, enum.Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class LinkType(str, enum.Enum):
    INTERNAL = "internal"
    EXTERNAL = "external"


class LinkAnalysisCheck(TimestampMixin, Base):
    """Persisted link-analysis task master row.

    The heavy per-link data lives in the ``link_findings`` child table so that
    results can be streamed/paginated efficiently.  Summary aggregates and
    overall verdicts are cached on this row for quick retrieval.
    """

    __tablename__ = "link_analysis_checks"

    __table_args__ = (
        Index("ix_link_analysis_checks_domain_created", "domain", "created_at"),
        Index("ix_link_analysis_checks_status", "status"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    url: Mapped[str] = mapped_column(Text, nullable=False)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default=LinkAnalysisCheckStatus.QUEUED.value
    )
    task_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    pages_crawled: Mapped[int | None] = mapped_column(Integer, nullable=True)

    summary: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    findings: Mapped[list[dict]] = mapped_column(JSONB, nullable=False, default=list)
    recommendations: Mapped[list[dict]] = mapped_column(
        JSONB, nullable=False, default=list
    )
    report_markdown: Mapped[str | None] = mapped_column(Text, nullable=True)
    cost_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)

    overall_status: Mapped[LinkAnalysisOverallStatus | None] = mapped_column(
        Enum(
            LinkAnalysisOverallStatus,
            name="link_analysis_overall_status",
            create_type=False,
            validate_strings=True,
        ),
        nullable=True,
    )
    severity: Mapped[LinkAnalysisSeverity | None] = mapped_column(
        Enum(
            LinkAnalysisSeverity,
            name="link_analysis_severity",
            create_type=False,
            validate_strings=True,
        ),
        nullable=True,
    )

    check_version: Mapped[str] = mapped_column(
        String(20), nullable=False, default="1.0.0"
    )

    findings_rel: Mapped[list["LinkFinding"]] = relationship(
        "LinkFinding",
        foreign_keys="LinkFinding.check_id",
        back_populates="check",
        cascade="all, delete-orphan",
        lazy="selectin",
    )


class LinkFinding(TimestampMixin, Base):
    """Individual link finding row — one per discovered link.

    Stores per-link detail so callers can paginate/stream the full link
    inventory without loading a monolithic JSONB blob.
    """

    __tablename__ = "link_findings"

    __table_args__ = (
        Index("ix_link_findings_check_type", "check_id", "link_type"),
        Index("ix_link_findings_url", "target_url"),
        Index("ix_link_findings_source", "source_url"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )

    check_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("link_analysis_checks.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    source_url: Mapped[str] = mapped_column(Text, nullable=False, index=True)

    target_url: Mapped[str] = mapped_column(Text, nullable=False, index=True)

    anchor_text: Mapped[str] = mapped_column(Text, nullable=False, default="")

    link_type: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default=LinkType.INTERNAL.value,
    )

    status_code: Mapped[int | None] = mapped_column(SmallInteger, nullable=True)

    is_broken: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    rel_flags: Mapped[dict] = mapped_column(
        JSONB, nullable=False, default=dict
    )

    crawl_depth: Mapped[int | None] = mapped_column(Integer, nullable=True)

    check: Mapped["LinkAnalysisCheck"] = relationship(
        "LinkAnalysisCheck",
        foreign_keys="LinkFinding.check_id",
        back_populates="findings_rel",
        lazy="selectin",
    )


__all__ = [
    "LinkAnalysisCheckStatus",
    "LinkAnalysisOverallStatus",
    "LinkAnalysisSeverity",
    "LinkType",
    "LinkAnalysisCheck",
    "LinkFinding",
]
