"""Standalone link analysis API."""
