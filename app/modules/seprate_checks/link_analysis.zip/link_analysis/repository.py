from typing import Optional, List, Dict, Any, Union
from uuid import UUID

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .model import (
    LinkAnalysisCheck,
    LinkAnalysisCheckStatus,
    LinkAnalysisOverallStatus,
    LinkAnalysisSeverity,
)


def _val(enum_or_str: Any) -> Any:
    if hasattr(enum_or_str, "value"):
        return enum_or_str.value
    return enum_or_str


class LinkAnalysisRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, check: LinkAnalysisCheck) -> LinkAnalysisCheck:
        self.db.add(check)
        await self.db.flush()
        await self.db.refresh(check)
        return check

    async def get(self, check_id: UUID) -> Optional[LinkAnalysisCheck]:
        result = await self.db.execute(
            select(LinkAnalysisCheck).where(LinkAnalysisCheck.id == check_id)
        )
        return result.scalar_one_or_none()

    async def update_progress(
        self,
        check_id: UUID,
        status: Union[LinkAnalysisCheckStatus, str],
        progress: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
    ) -> None:
        values: Dict[str, Any] = {"status": _val(status)}
        if progress is not None:
            values["progress"] = progress
        if error is not None:
            values["error"] = error

        await self.db.execute(
            update(LinkAnalysisCheck)
            .where(LinkAnalysisCheck.id == check_id)
            .values(**values)
        )
        await self.db.flush()

    async def update_completed(
        self,
        check_id: UUID,
        summary: Dict[str, Any],
        internal_links: List[Dict[str, Any]],
        external_links: List[Dict[str, Any]],
        broken_links: List[Dict[str, Any]],
        orphan_pages: List[Dict[str, Any]],
        redirects: List[Dict[str, Any]],
        overall_status: Union[LinkAnalysisOverallStatus, str, None],
        severity: Union[LinkAnalysisSeverity, str, None],
        findings: List[Dict[str, Any]],
        recommendations: List[Dict[str, Any]],
        report_markdown: str,
        cost_seconds: float,
    ) -> Optional[LinkAnalysisCheck]:
        await self.db.execute(
            update(LinkAnalysisCheck)
            .where(LinkAnalysisCheck.id == check_id)
            .values(
                status=_val(LinkAnalysisCheckStatus.COMPLETED),
                progress={"phase": "completed", "message": "Link analysis complete"},
                summary=summary,
                internal_links=internal_links,
                external_links=external_links,
                broken_links=broken_links,
                orphan_pages=orphan_pages,
                redirects=redirects,
                overall_status=_val(overall_status) if overall_status else None,
                severity=_val(severity) if severity else None,
                findings=findings,
                recommendations=recommendations,
                report_markdown=report_markdown,
                cost_seconds=cost_seconds,
                error=None,
            )
        )
        await self.db.flush()
        return await self.get(check_id)
