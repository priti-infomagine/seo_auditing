"""Asynchronous link analysis service: crawl, extract, analyze links."""
import asyncio
import time
from collections import deque
from typing import Callable, Dict, List, Optional, Set, Any, Tuple
from urllib.parse import urlparse, urljoin
from uuid import UUID

import httpx

from app.core.config import settings
from app.core.database import async_session_factory
from app.core.logger import logger

from app.modules.crawler.services.fetch_service import (
    fetch_page,
    FetchResult,
)
from app.modules.crawler.services.site_discovery_service import (
    SiteDiscoveryService,
    SiteDiscoveryResult,
)
from app.modules.parser.services.document_parser_service import (
    DocumentParserService,
    DocumentContext,
)
from app.modules.parser.extractors.link_extractor import LinkExtractor
from app.modules.parser.models.link_data import LinkData

from app.shared.utils.url_utils import normalize_host, normalize_url

from .model import (
    LinkAnalysisCheck,
    LinkAnalysisCheckStatus,
    LinkAnalysisOverallStatus,
    LinkAnalysisSeverity,
)
from .repository import LinkAnalysisRepository
from .schema import (
    LinkAnalysisIssue,
    LinkAnalysisRecommendation,
    LinkAnalysisSummary,
)


def _safe_update_state(
    update_state: Optional[Callable[[str, Optional[dict]], None]],
    state: str,
    meta: Optional[dict] = None,
) -> None:
    try:
        if update_state:
            update_state(state, meta)
    except Exception:
        pass


def _normalize_target_url(raw_url: str) -> Tuple[str, str]:
    cleaned = raw_url.strip()
    if not cleaned.startswith(("http://", "https://")):
        cleaned = f"https://{cleaned}"

    parsed = urlparse(cleaned)
    host = normalize_host(parsed.netloc or parsed.path)
    if not host:
        raise ValueError(f"Invalid URL or domain provided: {raw_url}")

    canonical_url = f"https://{host}"
    return canonical_url, host


class LinkAnalysisService:
    """Service to execute async link analysis crawl jobs."""

    MAX_PAGES: int = settings.CRAWL_MAX_PAGES
    MAX_DEPTH: int = 5
    MAX_CONCURRENCY: int = settings.LINK_CHECK_MAX_CONCURRENCY
    FETCH_TIMEOUT: float = settings.LINK_CHECK_TIMEOUT
    EXTERNAL_CHECK_TIMEOUT: float = settings.LINK_CHECK_TIMEOUT

    @classmethod
    async def prepare_check(
        cls,
        url: str,
        db: Optional[Any] = None,
    ) -> LinkAnalysisCheck:
        """Validate input and create initial queued record in DB."""
        canonical_url, domain = _normalize_target_url(url)

        check = LinkAnalysisCheck(
            url=canonical_url,
            domain=domain,
            status=LinkAnalysisCheckStatus.QUEUED,
            progress={"phase": "queued", "message": "Check queued in worker"},
            error=None,
        )
        if db is not None:
            repo = LinkAnalysisRepository(db)
            saved = await repo.create(check)
            await db.commit()
            return saved
        else:
            async with async_session_factory() as session:
                repo = LinkAnalysisRepository(session)
                saved = await repo.create(check)
                await session.commit()
                return saved

    async def run_check_async(
        self,
        check_id: UUID,
        url: str,
        update_state: Optional[Callable[[str, Optional[dict]], None]] = None,
    ) -> Dict[str, Any]:
        """Execute the link analysis crawl, extraction, and evaluation workflow."""
        start_time = time.perf_counter()
        canonical_url, domain = _normalize_target_url(url)

        async with async_session_factory() as session:
            repo = LinkAnalysisRepository(session)
            try:
                # 1. Update status to PROCESSING
                await repo.update_progress(
                    check_id,
                    LinkAnalysisCheckStatus.PROCESSING,
                    progress={"phase": "crawling", "message": f"Crawling {domain}..."},
                )
                await session.commit()

                _safe_update_state(update_state, "PROGRESS", meta={"phase": "crawling", "message": f"Crawling {domain}..."})

                # 2. Discover sitemap URLs for orphan detection
                sitemap_urls: Set[str] = set()
                try:
                    discovery = SiteDiscoveryService(
                        canonical_url,
                        timeout=int(self.FETCH_TIMEOUT),
                    )
                    result: SiteDiscoveryResult = await asyncio.wait_for(
                        discovery.discover(),
                        timeout=self.FETCH_TIMEOUT * 3,
                    )
                    for sitemap_evidence in result.sitemaps:
                        for page_url in sitemap_evidence.urls:
                            sitemap_urls.add(page_url)
                except Exception as exc:
                    logger.warning(f"Sitemap discovery failed for {domain}: {exc}")

                # 3. Crawl pages and extract links
                internal_links: List[dict] = []
                external_links: List[dict] = []
                broken_links: List[dict] = []
                redirects: List[dict] = []
                link_graph: Dict[str, Set[str]] = {}
                visited: Set[str] = set()
                crawl_queue: deque = deque()

                parsed_base = urlparse(canonical_url)
                base_host = normalize_host(parsed_base.netloc)

                crawl_queue.append((canonical_url, 0))

                pages_crawled = 0
                unique_external: Set[str] = set()
                external_link_sources: Dict[str, str] = {}
                external_link_source_url: Dict[str, str] = {}
                page_status: Dict[str, int] = {}
                external_link_source_url: Dict[str, str] = {}

                while crawl_queue and pages_crawled < self.MAX_PAGES:
                    current_url, depth = crawl_queue.popleft()

                    if depth >= self.MAX_DEPTH:
                        continue

                    try:
                        normalized = normalize_url(current_url)
                    except Exception:
                        continue

                    if normalized in visited:
                        continue
                    visited.add(normalized)

                    _safe_update_state(update_state, "PROGRESS", meta={
                        "phase": "crawling",
                        "message": f"Crawling page {pages_crawled + 1}/{self.MAX_PAGES}",
                        "pages_crawled": pages_crawled,
                    })

                    result = await fetch_page(
                        current_url,
                        timeout=self.FETCH_TIMEOUT * 3,
                        follow_redirects=True,
                    )
                    pages_crawled += 1

                    # Track redirects
                    if result.redirect_chain:
                        for redirect in result.redirect_chain:
                            redirects.append({
                                "original_url": normalized,
                                "redirect_url": redirect.location or "",
                                "status_code": redirect.status_code,
                                "source_url": normalized,
                            })

                    if not result.success or result.status_code == 0:
                        page_status[normalized] = 0
                        continue

                    page_status[normalized] = result.status_code

                    if result.status_code >= 400:
                        continue

                    if result.content_type and "text/html" not in result.content_type:
                        continue

                    # Parse and extract links
                    html_str = result.content.decode("utf-8", errors="ignore")
                    context = DocumentParserService().parse(html_str, normalized)
                    links = LinkExtractor().extract(context)

                    if normalized not in link_graph:
                        link_graph[normalized] = set()

                    page_host = normalize_host(urlparse(normalized).netloc)

                    for link in links:
                        absolute = link.absolute_url
                        if not absolute:
                            continue

                        href_lower = absolute.lower()

                        link_host = normalize_host(urlparse(absolute).netloc)

                        if link_host == base_host and href_lower.startswith(("http://", "https://")):
                            # Internal link
                            try:
                                target_norm = normalize_url(absolute)
                            except Exception:
                                target_norm = absolute

                            link_graph[normalized].add(target_norm)

                            internal_links.append({
                                "url": target_norm,
                                "anchor_text": link.text,
                                "rel": link.rel,
                                "status_code": 0,
                                "source_url": normalized,
                                "crawl_depth": depth,
                            })

                            # Enqueue for crawling if not visited
                            if target_norm not in visited:
                                crawl_queue.append((target_norm, depth + 1))
                        elif href_lower.startswith(("http://", "https://")):
                            # External link (only HTTP/HTTPS URLs — skip mailto:, tel:, ftp:, etc.)
                            unique_external.add(absolute)
                            external_link_sources[absolute] = link.text
                            external_link_source_url[absolute] = normalized

                # 4. Check external links via HEAD requests
                _safe_update_state(update_state, "PROGRESS", meta={
                    "phase": "checking_external",
                    "message": f"Checking {len(unique_external)} external link(s)...",
                })

                if external_status_map := await self._check_external_urls(unique_external):
                    for ext_url, status_code in external_status_map.items():
                        anchor_text = external_link_sources.get(ext_url, "")
                        source_url = external_link_source_url.get(ext_url, "")
                        external_links.append({
                            "url": ext_url,
                            "anchor_text": anchor_text,
                            "rel": [],
                            "status_code": status_code,
                            "is_broken": status_code >= 400 or status_code == 0,
                            "source_url": source_url,
                        })
                        if status_code >= 400 or status_code == 0:
                            broken_links.append({
                                "url": ext_url,
                                "status_code": status_code,
                                "error": f"HTTP {status_code}" if status_code > 0 else "connection_error",
                                "source_url": source_url,
                            })

                # 5. Resolve internal link status codes from crawl results
                for link in internal_links:
                    target_url = link["url"]
                    status = page_status.get(target_url, 0)
                    link["status_code"] = status
                    if status >= 400 or status == 0:
                        broken_links.append({
                            "url": target_url,
                            "status_code": status,
                            "error": f"HTTP {status}" if status > 0 else "fetch_failed",
                            "source_url": link["source_url"],
                        })

                # 6. Compute orphan pages
                visited_normalized = visited
                orphan_candidates = set()

                # Orphans: sitemap URLs not discovered during crawl
                for sitemap_url in sitemap_urls:
                    try:
                        sitemap_norm = normalize_url(sitemap_url)
                    except Exception:
                        sitemap_norm = sitemap_url
                    if sitemap_norm not in visited_normalized:
                        orphan_candidates.add(sitemap_url)

                # Orphans: crawled pages with zero inbound internal links
                inbound_counts: Dict[str, int] = {}
                for source_url, targets in link_graph.items():
                    for target in targets:
                        inbound_counts[target] = inbound_counts.get(target, 0) + 1

                for page_url in visited_normalized:
                    count = inbound_counts.get(page_url, 0)
                    if count == 0 and page_url != normalize_url(canonical_url):
                        orphan_candidates.add(page_url)

                orphan_pages = [
                    {
                        "url": url,
                        "inbound_links": inbound_counts.get(url, 0),
                    }
                    for url in sorted(orphan_candidates)
                ]

                # 7. Generate findings and recommendations
                findings: List[LinkAnalysisIssue] = []
                recommendations: List[LinkAnalysisRecommendation] = []

                if broken_links:
                    broken_internal = sum(1 for b in broken_links if b["source_url"])
                    broken_external = len(broken_links) - broken_internal
                    if broken_internal > 0:
                        findings.append(LinkAnalysisIssue(
                            code="broken_internal_links",
                            severity="high",
                            status="fail",
                            message=f"{broken_internal} internal link(s) return error status codes",
                            evidence=f"Broken URLs: {', '.join(b['url'] for b in broken_links[:5])}",
                        ))
                        recommendations.append(LinkAnalysisRecommendation(
                            code="broken_internal_links",
                            priority="high",
                            title="Fix broken internal links",
                            message=f"{broken_internal} internal links point to non-existent or error pages.",
                            fix="Update or remove the broken internal links, or redirect them to valid pages.",
                            where_to_fix="cms",
                            evidence=f"Found {broken_internal} broken internal links.",
                        ))
                    if broken_external > 0:
                        findings.append(LinkAnalysisIssue(
                            code="broken_external_links",
                            severity="medium",
                            status="warning",
                            message=f"{broken_external} external link(s) could not be reached",
                            evidence=f"URLs: {', '.join(b['url'] for b in broken_links[-broken_external:][:5])}",
                        ))
                        recommendations.append(LinkAnalysisRecommendation(
                            code="broken_external_links",
                            priority="medium",
                            title="Fix or remove broken external links",
                            message=f"{broken_external} external links are broken or unreachable.",
                            fix="Update broken external links to working URLs or remove them.",
                            where_to_fix="cms",
                        ))

                if orphan_pages:
                    findings.append(LinkAnalysisIssue(
                        code="orphan_pages",
                        severity="medium",
                        status="warning",
                        message=f"{len(orphan_pages)} orphan page(s) detected (no inbound internal links)",
                        evidence=f"Pages: {', '.join(p['url'] for p in orphan_pages[:5])}",
                    ))
                    recommendations.append(LinkAnalysisRecommendation(
                        code="orphan_pages",
                        priority="medium",
                        title="Address orphan pages",
                        message=f"{len(orphan_pages)} pages have no internal links pointing to them.",
                        fix="Add internal links from related pages to these orphan pages, or remove them if not needed.",
                        where_to_fix="cms",
                    ))

                if redirects:
                    findings.append(LinkAnalysisIssue(
                        code="redirects",
                        severity="low" if len(redirects) <= 5 else "medium",
                        status="warning",
                        message=f"{len(redirects)} redirect(s) detected during crawl",
                        evidence=f"Redirects: {', '.join(r['original_url'] for r in redirects[:5])}",
                    ))
                    recommendations.append(LinkAnalysisRecommendation(
                        code="redirects",
                        priority="low",
                        title="Minimize redirect chains",
                        message=f"{len(redirects)} redirect(s) were detected.",
                        fix="Update internal links to point directly to final destinations, avoiding unnecessary redirects.",
                        where_to_fix="cms",
                    ))

                # Compute overall status
                total_issues = len(findings)
                if total_issues == 0:
                    overall_status = LinkAnalysisOverallStatus.PASS
                    severity = LinkAnalysisSeverity.NONE
                    status_val = "pass"
                elif any(f.severity == "high" for f in findings):
                    overall_status = LinkAnalysisOverallStatus.FAIL
                    severity = LinkAnalysisSeverity.HIGH
                    status_val = "fail"
                elif any(f.severity == "medium" for f in findings):
                    overall_status = LinkAnalysisOverallStatus.WARNING
                    severity = LinkAnalysisSeverity.MEDIUM
                    status_val = "warning"
                else:
                    overall_status = LinkAnalysisOverallStatus.WARNING
                    severity = LinkAnalysisSeverity.LOW
                    status_val = "warning"

                # 8. Build summary
                total_links = len(internal_links) + len(external_links)
                summary = {
                    "pages_crawled": pages_crawled,
                    "total_links": total_links,
                    "internal_links": len(internal_links),
                    "external_links": len(external_links),
                    "broken_links": len(broken_links),
                    "orphan_pages": len(orphan_pages),
                    "redirects": len(redirects),
                    "total_issues": total_issues,
                }

                cost_seconds = round(time.perf_counter() - start_time, 3)

                report_markdown = self._generate_markdown_report(
                    domain=domain,
                    summary=summary,
                    overall_status=overall_status.value,
                    severity=severity.value,
                    internal_links=internal_links,
                    external_links=external_links,
                    broken_links=broken_links,
                    orphan_pages=orphan_pages,
                    redirects=redirects,
                    findings=findings,
                    recommendations=recommendations,
                )

                # 9. Persist COMPLETED state
                await repo.update_completed(
                    check_id=check_id,
                    summary=summary,
                    internal_links=internal_links,
                    external_links=external_links,
                    broken_links=broken_links,
                    orphan_pages=orphan_pages,
                    redirects=redirects,
                    overall_status=overall_status,
                    severity=severity,
                    findings=[f.model_dump(mode="json") for f in findings],
                    recommendations=[r.model_dump(mode="json") for r in recommendations],
                    report_markdown=report_markdown,
                    cost_seconds=cost_seconds,
                )
                await session.commit()

                _safe_update_state(update_state, "PROGRESS", meta={
                    "phase": "completed",
                    "message": "Link analysis complete",
                })

                logger.info(
                    f"LinkAnalysisService.run_check_async: completed for check_id={check_id}, "
                    f"pages={pages_crawled}, links={total_links}, issues={total_issues}"
                )

                return {
                    "status": LinkAnalysisCheckStatus.COMPLETED.value,
                    "check_id": str(check_id),
                    "domain": domain,
                    "overall_status": overall_status.value,
                    "total_links": total_links,
                    "total_issues": total_issues,
                    "cost_seconds": cost_seconds,
                }

            except Exception as exc:
                logger.error(
                    f"LinkAnalysisService.run_check_async failed for check_id={check_id}: {exc}",
                    exc_info=True,
                )
                await repo.update_progress(
                    check_id,
                    LinkAnalysisCheckStatus.FAILED,
                    progress={"phase": "failed", "message": str(exc)},
                    error=str(exc),
                )
                await session.commit()
                raise


    async def _check_external_urls(self, urls: Set[str]) -> Dict[str, int]:
        """HEAD-check a set of external URLs concurrently.

        Returns {url: status_code}. status_code is 0 for failures.
        """
        if not urls:
            return {}

        results: Dict[str, int] = {}
        semaphore = asyncio.Semaphore(
            settings.LINK_CHECK_MAX_CONCURRENCY
            if settings.LINK_CHECK_EXTERNAL_ENABLED
            else 5
        )

        async with httpx.AsyncClient(
            timeout=self.EXTERNAL_CHECK_TIMEOUT,
            follow_redirects=False,
            headers={"User-Agent": "SEOAudit-Bot/1.0"},
        ) as client:

            async def _check(url: str) -> None:
                async with semaphore:
                    try:
                        resp = await client.head(url)
                        results[url] = resp.status_code
                    except httpx.TimeoutException:
                        results[url] = 0
                    except httpx.HTTPError:
                        results[url] = 0
                    except Exception:
                        results[url] = 0

            await asyncio.gather(*(_check(url) for url in urls))

        return results

    # async def _check_external_urls(self, urls: Set[str]) -> Dict[str, int]:
    #     """HEAD-check a set of external URLs concurrently.

    #     Returns {url: status_code}. status_code is 0 for failures.
    #     """
    #     if not urls:
    #         return {}

    #     results: Dict[str, int] = {}
    #     semaphore = asyncio.Semaphore(
    #         settings.LINK_CHECK_MAX_CONCURRENCY if settings.LINK_CHECK_EXTERNAL_ENABLED else 5
    #     )

    #     async def _check(url: str) -> None:
    #         async with semaphore:
    #             try:
    #                 async with httpx.AsyncClient(
    #                     timeout=self.EXTERNAL_CHECK_TIMEOUT,
    #                     follow_redirects=False,
    #                     headers={"User-Agent": "SEOAudit-Bot/1.0"},
    #                 ) as client:
    #                     resp = await client.head(url)
    #                     results[url] = resp.status_code
    #             except httpx.TimeoutException:
    #                 results[url] = 0
    #             except Exception:
    #                 results[url] = 0

    #     await asyncio.gather(*[_check(u) for u in urls])
    #     return results

    def _generate_markdown_report(
        self,
        domain: str,
        summary: dict,
        overall_status: str,
        severity: str,
        internal_links: List[dict],
        external_links: List[dict],
        broken_links: List[dict],
        orphan_pages: List[dict],
        redirects: List[dict],
        findings: List[LinkAnalysisIssue],
        recommendations: List[LinkAnalysisRecommendation],
    ) -> str:
        lines = [
            f"# Link Analysis Report for `{domain}`",
            "",
            f"**Overall Status:** `{overall_status.upper()}` | **Severity:** `{severity.upper()}`",
            "",
            "## Summary",
            f"- **Pages Crawled:** {summary['pages_crawled']}",
            f"- **Total Links:** {summary['total_links']}",
            f"- **Internal Links:** {summary['internal_links']}",
            f"- **External Links:** {summary['external_links']}",
            f"- **Broken Links:** {summary['broken_links']}",
            f"- **Orphan Pages:** {summary['orphan_pages']}",
            f"- **Redirects:** {summary['redirects']}",
            f"- **Total Issues:** {summary['total_issues']}",
            "",
            "## Issues and Findings",
        ]

        if not findings:
            lines.append("- *No issues detected. All link checks passed successfully.*")
        else:
            for f in findings:
                lines.append(f"- **[{f.severity.upper()}] `{f.code}`**: {f.message}")
                if f.evidence:
                    lines.append(f"  - *Evidence:* {f.evidence}")

        lines.extend(["", "## Recommendations"])
        if not recommendations:
            lines.append("- *No action required.*")
        else:
            for r in recommendations:
                lines.append(f"### `{r.code}`: {r.title}")
                lines.append(f"- **Priority:** {r.priority.capitalize()}")
                lines.append(f"- **Action:** {r.fix}")
                lines.append("")

        return "\n".join(lines).rstrip()
