"""Asynchronous Link Analysis API routes with polling.

Endpoints:
- POST /check               — Queue an asynchronous link analysis (HTTP 202)
- GET  /status/{check_id}   — Poll progress and retrieve status
- GET  /result/{check_id}   — Retrieve stored results once completed
"""
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.logger import logger
from app.shared.tasks.celery_app import celery_app

from .model import LinkAnalysisCheck, LinkAnalysisCheckStatus
from .repository import LinkAnalysisRepository
from .schema import (
    LinkAnalysisQueuedResponse,
    LinkAnalysisRequest,
    LinkAnalysisResultResponse,
    LinkAnalysisStatusResponse,
    LinkAnalysisIssue,
    LinkAnalysisRecommendation,
    LinkAnalysisSummary,
    InternalLink,
    ExternalLink,
    BrokenLink,
    OrphanPage,
    Redirect,
)
from .service import LinkAnalysisService


router = APIRouter()


def _str_status(val) -> str:
    if hasattr(val, "value"):
        return str(val.value)
    return str(val) if val is not None else ""


def _to_result_response(check: LinkAnalysisCheck) -> LinkAnalysisResultResponse:
    """Serialize a completed LinkAnalysisCheck DB model to LinkAnalysisResultResponse."""
    summary_data = check.summary or {}
    summary = LinkAnalysisSummary(
        pages_crawled=summary_data.get("pages_crawled", 0),
        total_links=summary_data.get("total_links", 0),
        internal_links=summary_data.get("internal_links", 0),
        external_links=summary_data.get("external_links", 0),
        broken_links=summary_data.get("broken_links", 0),
        orphan_pages=summary_data.get("orphan_pages", 0),
        redirects=summary_data.get("redirects", 0),
        total_issues=summary_data.get("total_issues", 0),
    )

    internal_links = [
        InternalLink(
            url=item.get("url", ""),
            anchor_text=item.get("anchor_text", ""),
            rel=item.get("rel", []),
            status_code=item.get("status_code", 0),
            source_url=item.get("source_url", ""),
            crawl_depth=item.get("crawl_depth", 0),
        )
        for item in (check.internal_links or [])
    ]

    external_links = [
        ExternalLink(
            url=item.get("url", ""),
            anchor_text=item.get("anchor_text", ""),
            rel=item.get("rel", []),
            status_code=item.get("status_code", 0),
            is_broken=item.get("is_broken", False),
            source_url=item.get("source_url", ""),
        )
        for item in (check.external_links or [])
    ]

    broken_links = [
        BrokenLink(
            url=item.get("url", ""),
            status_code=item.get("status_code", 0),
            error=item.get("error"),
            source_url=item.get("source_url", ""),
        )
        for item in (check.broken_links or [])
    ]

    orphan_pages = [
        OrphanPage(
            url=item.get("url", ""),
            inbound_links=item.get("inbound_links", 0),
        )
        for item in (check.orphan_pages or [])
    ]

    redirects = [
        Redirect(
            original_url=item.get("original_url", ""),
            redirect_url=item.get("redirect_url", ""),
            status_code=item.get("status_code", 0),
            source_url=item.get("source_url", ""),
        )
        for item in (check.redirects or [])
    ]

    findings = [
        LinkAnalysisIssue(
            code=f.get("code", "unknown"),
            severity=f.get("severity", "medium"),
            status=f.get("status", "warning"),
            message=f.get("message", ""),
            evidence=f.get("evidence"),
        )
        for f in (check.findings or [])
    ]

    recommendations = [
        LinkAnalysisRecommendation(
            code=r.get("code", "unknown"),
            priority=r.get("priority", "medium"),
            title=r.get("title", ""),
            message=r.get("message", ""),
            fix=r.get("fix", ""),
            where_to_fix=r.get("where_to_fix"),
            evidence=r.get("evidence"),
        )
        for r in (check.recommendations or [])
    ]

    return LinkAnalysisResultResponse(
        check_id=check.id,
        url=check.url,
        domain=check.domain,
        status=check.status,
        checked_at=check.updated_at.isoformat() if check.updated_at else None,
        overall_status=_str_status(check.overall_status) if check.overall_status else None,
        severity=_str_status(check.severity) if check.severity else None,
        summary=summary,
        internal_links=internal_links,
        external_links=external_links,
        broken_links=broken_links,
        orphan_pages=orphan_pages,
        redirects=redirects,
        findings=findings,
        recommendations=recommendations,
        report_markdown=check.report_markdown,
        cost_seconds=check.cost_seconds,
    )


async def _get_check_or_404(check_id: str, db: AsyncSession) -> LinkAnalysisCheck:
    try:
        parsed_id = UUID(check_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid check ID format (must be a valid UUID)",
        ) from exc

    check = await LinkAnalysisRepository(db).get(parsed_id)
    if check is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Link analysis check with ID '{check_id}' not found",
        )
    return check


@router.post(
    "/check",
    response_model=LinkAnalysisQueuedResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Queue an asynchronous Link Analysis",
    description=(
        "Enqueues an asynchronous link analysis check on the `crawler` queue. "
        "Returns immediately with HTTP 202 containing the `check_id`. "
        "Poll `GET /api/v1/link-analysis/status/{check_id}` for progress and results."
    ),
)
async def check_links(
    body: LinkAnalysisRequest,
    db: AsyncSession = Depends(get_db),
) -> LinkAnalysisQueuedResponse:
    try:
        check = await LinkAnalysisService.prepare_check(body.url, db)

        # Dispatch background task to Celery crawler queue
        task = celery_app.send_task(
            "link_analysis.run_check",
            args=[str(check.id), check.url],
            queue="crawler",
        )
        check.task_id = task.id
        await db.commit()

        return LinkAnalysisQueuedResponse(
            check_id=check.id,
            task_id=task.id,
            url=check.url,
            domain=check.domain,
            status=check.status,
            created_at=check.created_at.isoformat() if check.created_at else None,
        )
    except ValueError as exc:
        logger.warning("check_links: validation error: %s", exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    except Exception as exc:
        logger.error("check_links: unexpected error: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while queuing the link analysis check",
        )


@router.get(
    "/status/{check_id}",
    response_model=LinkAnalysisStatusResponse,
    summary="Poll status and progress of a link analysis check",
    description=(
        "Poll this endpoint to check if the job is queued, processing, completed, "
        "or failed."
    ),
)
async def get_check_status(
    check_id: str,
    db: AsyncSession = Depends(get_db),
) -> LinkAnalysisStatusResponse:
    check = await _get_check_or_404(check_id, db)

    return LinkAnalysisStatusResponse(
        check_id=check.id,
        url=check.url,
        domain=check.domain,
        status=check.status,
        progress=check.progress,
        error=check.error,
    )


@router.get(
    "/result/{check_id}",
    response_model=LinkAnalysisResultResponse,
    summary="Get completed link analysis results",
    description="Retrieve the complete link analysis findings once completed.",
)
async def get_check_result(
    check_id: str,
    db: AsyncSession = Depends(get_db),
) -> LinkAnalysisResultResponse:
    check = await _get_check_or_404(check_id, db)

    status_str = _str_status(check.status)
    if status_str != LinkAnalysisCheckStatus.COMPLETED.value:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Link analysis check is not completed yet (current status: '{status_str}')",
        )

    return _to_result_response(check)
