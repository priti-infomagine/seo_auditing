"""Schemas for the asynchronous Link Analysis API."""
from typing import List, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from .model import LinkAnalysisCheckStatus


class LinkAnalysisRequest(BaseModel):
    url: str = Field(
        ...,
        min_length=1,
        description="Website URL or bare domain to analyze (e.g. example.com, https://example.com)",
    )

    @field_validator("url")
    @classmethod
    def validate_url(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("url must not be empty")
        return normalized


class LinkAnalysisQueuedResponse(BaseModel):
    """Returned immediately upon queuing the analysis (HTTP 202)."""
    check_id: UUID = Field(..., description="Unique check identifier")
    task_id: Optional[str] = Field(None, description="Celery background task ID")
    url: str = Field(..., description="Target URL")
    domain: str = Field(..., description="Normalized domain")
    status: LinkAnalysisCheckStatus = Field(
        default=LinkAnalysisCheckStatus.QUEUED, description="Current check status"
    )
    created_at: Optional[str] = Field(None, description="ISO timestamp of creation")


class LinkAnalysisIssue(BaseModel):
    code: str = Field(..., description="Stable issue identifier code")
    severity: Literal["none", "low", "medium", "high", "critical"] = Field(
        ..., description="Issue severity"
    )
    status: Literal["pass", "warning", "fail"] = Field(
        default="warning", description="Status classification"
    )
    message: str = Field(..., description="Human-readable issue description")
    evidence: Optional[str] = Field(None, description="Supporting evidence")


class LinkAnalysisRecommendation(BaseModel):
    code: str = Field(..., description="Associated issue code")
    priority: Literal["critical", "high", "medium", "low", "info"] = Field(
        ..., description="Fix priority"
    )
    title: str = Field(..., description="Short recommendation title")
    message: str = Field(..., description="Detailed explanation")
    fix: str = Field(..., description="Actionable fix instruction")
    where_to_fix: Optional[str] = Field(None, description="Where to apply the fix")
    evidence: Optional[str] = Field(None, description="Context / evidence")


class InternalLink(BaseModel):
    url: str = Field(..., description="Absolute URL of the linked page")
    anchor_text: str = Field(..., description="Text content of the anchor")
    rel: List[str] = Field(default_factory=list, description="rel attribute values (e.g. nofollow)")
    status_code: int = Field(default=0, description="HTTP status code of the target page")
    source_url: str = Field(..., description="URL of the page containing this link")
    crawl_depth: int = Field(default=0, description="Depth at which this link was discovered")


class ExternalLink(BaseModel):
    url: str = Field(..., description="Absolute URL of the external link")
    anchor_text: str = Field(..., description="Text content of the anchor")
    rel: List[str] = Field(default_factory=list, description="rel attribute values")
    status_code: int = Field(default=0, description="HTTP status code of the external URL")
    is_broken: bool = Field(default=False, description="Whether the external link is broken")
    source_url: str = Field(..., description="Page that links to this external URL")


class BrokenLink(BaseModel):
    url: str = Field(..., description="Absolute URL that returned an error")
    status_code: int = Field(default=0, description="HTTP status code or error code")
    error: Optional[str] = Field(None, description="Error type or message")
    source_url: str = Field(..., description="Page that links to this broken URL")


class OrphanPage(BaseModel):
    url: str = Field(..., description="Absolute URL of the orphan page")
    inbound_links: int = Field(default=0, description="Number of internal pages linking to this page")


class Redirect(BaseModel):
    original_url: str = Field(..., description="The URL that was redirected from")
    redirect_url: str = Field(..., description="The URL that was redirected to")
    status_code: int = Field(..., description="HTTP redirect status code (301, 302, etc.)")
    source_url: str = Field(..., description="Page that contained the redirecting link")


class LinkAnalysisSummary(BaseModel):
    pages_crawled: int = Field(0, description="Number of pages crawled")
    total_links: int = Field(0, description="Total number of links found")
    internal_links: int = Field(0, description="Number of internal links")
    external_links: int = Field(0, description="Number of external links")
    broken_links: int = Field(0, description="Number of broken links")
    orphan_pages: int = Field(0, description="Number of orphan pages")
    redirects: int = Field(0, description="Number of redirects detected")
    total_issues: int = Field(0, description="Total issues detected")


class LinkAnalysisResultResponse(BaseModel):
    """Complete link analysis result payload."""
    check_id: UUID
    url: str
    domain: str
    status: LinkAnalysisCheckStatus
    checked_at: Optional[str] = None
    overall_status: Optional[str] = None
    severity: Optional[str] = None
    summary: Optional[LinkAnalysisSummary] = None
    internal_links: List[InternalLink] = Field(default_factory=list)
    external_links: List[ExternalLink] = Field(default_factory=list)
    broken_links: List[BrokenLink] = Field(default_factory=list)
    orphan_pages: List[OrphanPage] = Field(default_factory=list)
    redirects: List[Redirect] = Field(default_factory=list)
    findings: List[LinkAnalysisIssue] = Field(default_factory=list)
    recommendations: List[LinkAnalysisRecommendation] = Field(default_factory=list)
    report_markdown: Optional[str] = Field(None, description="Generated markdown audit report")
    cost_seconds: Optional[float] = None


class LinkAnalysisStatusResponse(BaseModel):
    """Response returned when polling /status/{check_id}."""
    check_id: UUID
    url: str
    domain: str
    status: LinkAnalysisCheckStatus
    progress: Optional[dict] = None
    error: Optional[str] = None
