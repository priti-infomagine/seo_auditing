"""
Pydantic schemas package.
"""