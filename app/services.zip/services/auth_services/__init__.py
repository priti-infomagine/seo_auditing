"""
Auth services package.
"""