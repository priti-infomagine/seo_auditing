from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── App ──────────────────────────────────────────────────────────
    APP_NAME: str = "Automated SEO & Website Audit Tool"
    DEBUG: bool = False
    DATABASE_ECHO: bool = False
    SECRET_KEY: str = "change-me-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    COOKIE_SECURE: bool = False  # Set to True in production (HTTPS)
    # ── Database ─────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/seo_audit"
    DATABASE_SYNC_URL: Optional[str] = None  # for alembic migrations

    @property
    def sync_database_url(self) -> str:
        """Return a sync-compatible URL (psycopg2) for Alembic."""
        if self.DATABASE_SYNC_URL:
            return self.DATABASE_SYNC_URL
        # Replace asyncpg driver with psycopg2 for sync operations
        return self.DATABASE_URL.replace("+asyncpg", "+psycopg2")

    # ── Redis / Cache ────────────────────────────────────────────────
    REDIS_URL: str = "redis://127.0.0.1:6379/0"
    REDIS_BROKER_URL: str = "redis://127.0.0.1:6379/0"
    REDIS_BACKEND_URL: str = "redis://127.0.0.1:6379/1"

    # ── Email (SMTP) ─────────────────────────────────────────────────
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM_EMAIL: str = "noreply@seoaudit.local"

    # ── OTP ──────────────────────────────────────────────────────────
    OTP_EXPIRE_MINUTES: int = 10
    CRAWL_MAX_PAGES: int = 100

    # ── Timezone ─────────────────────────────────────────────────────
    TZ: str = "UTC"

    # ── CORS ─────────────────────────────────────────────────────────
    CORS_ORIGINS: list[str] = ["http://localhost:3000", "http://localhost:5173"]

    # ── External APIs ────────────────────────────────────────────────
    OPENAI_API_KEY: str = ""
    GOOGLE_PAGESPEED_API_KEY: str = ""
    DATAFORSEO_LOGIN: str = ""
    DATAFORSEO_PASSWORD: str = ""

    # ── SERP Rank Check ─────────────────────────────────────
    SERP_PROVIDER_TIMEOUT: float = 30.0
    SERP_TASK_SOFT_TIME_LIMIT: int = 45
    SERP_TASK_TIME_LIMIT: int = 60
    SERP_PREVIEW_DIR: str = "output/serp_previews"
    SERP_STUCK_JOB_TIMEOUT_SECONDS: int = 90
    SERP_TOP_RESULTS_LIMIT: int = 10

    # ── SEO Scorer Weights ──────────────────────────────────────────
    # JSON object mapping category -> weight. Weights are normalized to sum=1.
    # Example: '{"on_page": 0.25, "technical": 0.15, "content": 0.20, "links": 0.10, "images": 0.05, "schema": 0.05, "social": 0.05, "security": 0.10, "accessibility": 0.05, "performance": 0.05}'
    SEO_SCORER_WEIGHTS: Optional[str] = None

    # ── Ollama Chat ─────────────────────────────────────────────────
    OLLAMA_BASE_URL: str = "http://127.0.0.1:11434"
    OLLAMA_MODEL: str = "qwen3:1.7b"
    OLLAMA_TIMEOUT: int = 2
    OLLAMA_TEMPERATURE: float = 0.1

    # ── Broken Link Checking ────────────────────────────────────────
    LINK_CHECK_TIMEOUT: float = 10.0
    LINK_CHECK_MAX_CONCURRENCY: int = 5
    LINK_CHECK_EXTERNAL_ENABLED: bool = True

    # ── Link Analysis ───────────────────────────────────────────────
    LINK_ANALYSIS_MAX_PAGES: int = 2000
    LINK_ANALYSIS_MAX_DEPTH: int = 5
    LINK_ANALYSIS_CRAWL_CONCURRENCY: int = 10
    LINK_ANALYSIS_PAGE_TIMEOUT: float = 20.0
    LINK_ANALYSIS_MAX_REDIRECT_HOPS: int = 5
    LINK_ANALYSIS_MAX_EXTERNAL_CHECKS: int = 100
    LINK_ANALYSIS_MAX_SITEMAP_ONLY_CHECKS: int = 500
    LINK_ANALYSIS_PER_HOST_CONCURRENCY: int = 3
    LINK_ANALYSIS_EVIDENCE_SOURCE_CAP: int = 20
    LINK_ANALYSIS_DEEP_PAGE_THRESHOLD: int = 3
    LINK_ANALYSIS_MAX_OUTLINKS: int = 150
    LINK_ANALYSIS_PROGRESS_EVERY: int = 25
    LINK_ANALYSIS_TIME_LIMIT: int = 1800
    LINK_ANALYSIS_SOFT_TIME_LIMIT: int = 1700

    # ── Chat Auth ───────────────────────────────────────────────────
    CHAT_AUTH_ENABLED: bool = False

    # ── Report Generation & Delivery ─────────────────────────────────
    DEFAULT_SITE_CATEGORY: str = "ecommerce"
    REPORT_OUTPUT_DIR: str = "none"
    REPORT_DEFAULT_RECIPIENT_EMAIL: str = "report@yopmail.com"
    REPORT_MAX_AFFECTED_PAGES_SHOWN: int =25
    REPORT_LOGO_URL: str = "C:\\Users\\user\\Downloads\\logo.jpg"
    COMPANY_NAME: str = "Info@magine"
    COPYRIGHT_TEXT: str = "Confidential Report"


settings = Settings()
