"""
Audit Celery tasks.

Tasks:
  - audit.parse_crawl: DB-backed parse phase
  - audit.evaluate_rules: Rule evaluation phase
  - audit.score_project: Scoring + output file generation
  - audit.run_analysis_pipeline: Full pipeline (parse → evaluate → score)

All tasks use audit_id (== audit_id) as the single tracking key.
All tasks are fault-tolerant: per-page/rule failures are caught and
recorded; only system-level failures cause the task to fail.
"""
import asyncio
import json
import os
import sys
from uuid import UUID

from app.core.logger import logger
from app.modules.audit.services.db_parser_service import DBParserService
from app.modules.audit.services.rule_evaluator_service import RuleEvaluatorService
from app.modules.audit.services.analysis_scorer_service import AnalysisScorerService
from app.shared.tasks.celery_app import celery_app
from app.shared.tasks.db import run_async


@celery_app.task(
    name="audit.parse_crawl",
    queue="audit",
    autoretry_for=(Exception,),
    retry_backoff=True,
    retry_backoff_max=300,
    max_retries=3,
    acks_late=True,
    time_limit=3600,
    soft_time_limit=3300,
)
def parse_crawl(audit_id: str, force: bool = False) -> dict:
    """
    Celery task: parse all crawled pages for a crawl job and persist
    ParsedPageFact rows to PostgreSQL.

    Args:
        audit_id: The audit ID (== audit_id).

    Returns:
        Summary dict from DBParserService.parse_crawl()
    """
    logger.info(
        f"audit.parse_crawl: task started for audit_id={audit_id}"
    )

    async def _run():
        from app.core.database import async_session_factory
        async with async_session_factory() as db:
            service = DBParserService(db)
            result = await service.parse_crawl(UUID(audit_id), force=force)
            await db.commit()
            return result

    try:
        result = run_async(_run())
        logger.info(
            f"audit.parse_crawl: task finished for audit_id={audit_id}"
        )
        return result
    except Exception as exc:
        logger.error(
            f"audit.parse_crawl: task failed for audit_id={audit_id}: {exc}",
            exc_info=True,
        )
        raise


@celery_app.task(
    name="audit.evaluate_rules",
    queue="audit",
    autoretry_for=(Exception,),
    retry_backoff=True,
    retry_backoff_max=300,
    max_retries=3,
    acks_late=True,
    time_limit=3600,
    soft_time_limit=3300,
)
def evaluate_rules(audit_id: str, force: bool = False) -> dict:
    """
    Celery task: run all 60+ SEO rules against each parsed page and
    persist RuleEvaluationResult rows to PostgreSQL.

    Args:
        audit_id: The audit ID (== audit_id).

    Returns:
        Summary dict from RuleEvaluatorService.evaluate_crawl()
    """
    logger.info(
        f"audit.evaluate_rules: task started for audit_id={audit_id}"
    )

    async def _run():
        from app.core.database import async_session_factory
        async with async_session_factory() as db:
            service = RuleEvaluatorService(db)
            result = await service.evaluate_crawl(UUID(audit_id), force=force)
            await db.commit()
            return result

    try:
        result = run_async(_run())
        logger.info(
            f"audit.evaluate_rules: task finished for audit_id={audit_id}"
        )
        return result
    except Exception as exc:
        logger.error(
            f"audit.evaluate_rules: task failed for audit_id={audit_id}: {exc}",
            exc_info=True,
        )
        raise


@celery_app.task(
    name="audit.score_project",
    queue="audit",
    autoretry_for=(Exception,),
    retry_backoff=True,
    retry_backoff_max=300,
    max_retries=3,
    acks_late=True,
    time_limit=3600,
    soft_time_limit=3300,
)
def score_project(audit_id: str, force: bool = False) -> dict:
    """
    Celery task: score the rule evaluation results, persist SeoAnalysisRun,
    and write the output JSON file.

    Args:
        audit_id: The audit ID (== audit_id).

    Returns:
        Dict from AnalysisScorerService.score_project()
    """
    logger.info(
        f"audit.score_project: task started for audit_id={audit_id}"
    )

    async def _run():
        from app.core.database import async_session_factory
        async with async_session_factory() as db:
            service = AnalysisScorerService(db)
            result = await service.score_project(UUID(audit_id), force=force)
            await db.commit()
            return result

    try:
        result = run_async(_run())
        logger.info(
            f"audit.score_project: task finished for audit_id={audit_id}"
        )
        return result
    except Exception as exc:
        logger.error(
            f"audit.score_project: task failed for audit_id={audit_id}: {exc}",
            exc_info=True,
        )
        raise


@celery_app.task(
    name="audit.run_analysis_pipeline",
    queue="audit",
    bind=True,
    autoretry_for=(Exception,),
    retry_backoff=True,
    retry_backoff_max=300,
    max_retries=3,
    acks_late=True,
    time_limit=3600,
    soft_time_limit=3300,
)
def run_analysis_pipeline(self, audit_id: str, force: bool = False) -> dict:
    """
    Celery task: run the full analysis pipeline sequentially.

    1. Parse: parse all crawl pages → parsed_page_facts
    2. Evaluate: run all rules → rule_evaluation_results
    3. Score: aggregate, score, persist, write output file → seo_analysis_runs

    Each stage is fault-tolerant — errors in one stage don't prevent
    the next from running.

    Args:
        audit_id: The audit ID (== audit_id).

    Returns:
        Dict with results from all three stages.
    """
    logger.info(
        f"audit.run_analysis_pipeline: task started for audit_id={audit_id}"
    )
    task_id = self.request.id

    def _report_progress(stage: str) -> None:
        if task_id:
            self.update_state(
                task_id=task_id,
                state="PROGRESS",
                meta={"stage": stage, "audit_id": audit_id},
            )

    async def _run():
        from app.core.database import async_session_factory

        results: dict = {
            "audit_id": audit_id,
        }

        # Stage 0: Broken link check (runs after crawl, before parse)
        _report_progress("link_check")
        logger.info(
            f"audit.run_analysis_pipeline: STAGE link_check starting "
            f"audit_id={audit_id}"
        )
        try:
            async with async_session_factory() as db:
                from app.modules.crawler.services.broken_link_checker import BrokenLinkChecker
                checker = BrokenLinkChecker(db)
                results["link_check"] = (await checker.check_links(UUID(audit_id))).to_dict()
                await db.commit()
            logger.info(
                f"audit.run_analysis_pipeline: STAGE link_check finished "
                f"audit_id={audit_id}"
            )
        except Exception as exc:
            logger.error(
                f"audit.run_analysis_pipeline: link_check stage failed: {exc}",
                exc_info=True,
            )
            results["link_check"] = {"error": str(exc)}

        # Stage 1: Parse
        _report_progress("parse")
        logger.info(
            f"audit.run_analysis_pipeline: STAGE parse starting "
            f"audit_id={audit_id}, force={force}"
        )
        try:
            async with async_session_factory() as db:
                parser = DBParserService(db)
                results["parse"] = await parser.parse_crawl(
                    UUID(audit_id), force=force
                )
                await db.commit()
            logger.info(
                f"audit.run_analysis_pipeline: STAGE parse finished "
                f"audit_id={audit_id}"
            )
        except Exception as exc:
            logger.error(
                f"audit.run_analysis_pipeline: parse stage failed: {exc}",
                exc_info=True,
            )
            results["parse"] = {"error": str(exc)}

        # Stage 2: Evaluate
        _report_progress("evaluate")
        logger.info(
            f"audit.run_analysis_pipeline: STAGE evaluate starting "
            f"audit_id={audit_id}, force={force}"
        )
        try:
            async with async_session_factory() as db:
                evaluator = RuleEvaluatorService(db)
                results["evaluate"] = await evaluator.evaluate_crawl(
                    UUID(audit_id), force=force
                )
                await db.commit()
            logger.info(
                f"audit.run_analysis_pipeline: STAGE evaluate finished "
                f"audit_id={audit_id}"
            )
        except Exception as exc:
            logger.error(
                f"audit.run_analysis_pipeline: evaluate stage failed: {exc}",
                exc_info=True,
            )
            results["evaluate"] = {"error": str(exc)}

        # Stage 3: Score
        _report_progress("score")
        logger.info(
            f"audit.run_analysis_pipeline: STAGE score starting "
            f"audit_id={audit_id}, force={force}"
        )
        try:
            async with async_session_factory() as db:
                scorer = AnalysisScorerService(db)
                results["score"] = await scorer.score_project(
                    UUID(audit_id), force=force
                )
                await db.commit()
            logger.info(
                f"audit.run_analysis_pipeline: STAGE score finished "
                f"audit_id={audit_id}"
            )
        except Exception as exc:
            logger.error(
                f"audit.run_analysis_pipeline: score stage failed: {exc}",
                exc_info=True,
            )
            results["score"] = {"error": str(exc)}

        results["status"] = "completed"

        # Cache result and pipeline status in Redis for zero-DB polling
        try:
            from app.core.redis import get_redis
            redis_client = get_redis()
            if redis_client:
                score_data = results.get("score")
                if isinstance(score_data, dict) and "error" not in score_data:
                    await redis_client.set(
                        f"audit:result:{audit_id}:full",
                        json.dumps(score_data, default=str),
                        ex=86400,
                    )
                    status_payload = {
                        "audit_id": str(audit_id),
                        "parse_status": "completed",
                        "evaluate_status": "completed",
                        "score_status": "completed",
                        "overall_score": score_data.get("summary", {}).get("score"),
                        "grade": score_data.get("summary", {}).get("grade"),
                        "pages_parsed": score_data.get("audit", {}).get("pages", {}).get("analyzed", 0),
                        "output_file_path": score_data.get("output_file_path"),
                    }
                    await redis_client.set(
                        f"audit:status:{audit_id}",
                        json.dumps(status_payload, default=str),
                        ex=86400,
                    )
        except Exception as redis_exc:
            logger.debug(f"Failed to cache audit result in Redis: {redis_exc}")

        return results

    try:
        result = run_async(_run())
        logger.info(
            f"audit.run_analysis_pipeline: task finished for "
            f"audit_id={audit_id}"
        )
        return result
    except Exception as exc:
        logger.error(
            f"audit.run_analysis_pipeline: pipeline failed for "
            f"audit_id={audit_id}: {exc}",
            exc_info=True,
        )
        raise
