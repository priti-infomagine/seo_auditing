"""
Pydantic schemas for the DB-backed analysis pipeline API endpoints.

All schemas use `audit_id` (== `audit_id`) as the single tracking key.
"""
from typing import Optional, Dict, Any, List, Union
from uuid import UUID
from pydantic import BaseModel, Field

from app.modules.audit.schemas.audit_response_schemas import UnifiedAuditResponse


class ParseTriggerRequest(BaseModel):
    """Request to trigger DB-backed parsing for a crawl."""

    audit_id: Optional[UUID] = Field(
        None,
        description="Audit identifier (== audit_id).",
    )
    force: bool = Field(
        False,
        description="If True, re-parse pages that already have parsed facts.",
    )


class EvaluateTriggerRequest(BaseModel):
    """Request to trigger rule evaluation for a crawl."""

    audit_id: Optional[UUID] = Field(
        None,
        description="Audit identifier (== audit_id).",
    )
    force: bool = Field(
        False,
        description="If True, re-evaluate rules even if results already exist.",
    )


class ScoreTriggerRequest(BaseModel):
    """Request to trigger scoring for a crawl."""

    audit_id: Optional[UUID] = Field(
        None,
        description="Audit identifier (== audit_id).",
    )
    force: bool = Field(
        False,
        description="If True, re-score even if analysis already exists.",
    )


class PipelineStatusResponse(BaseModel):
    """Status of all pipeline stages for an audit."""

    audit_id: str = Field(..., description="Audit identifier")
    audit_id: str = Field(..., description="Crawl job identifier (== audit_id)")
    parse_status: str = Field(..., description="pending | completed | failed | missing")
    evaluate_status: str = Field(..., description="pending | completed | failed | missing")
    score_status: str = Field(..., description="pending | completed | failed | missing")
    pages_parsed: int = Field(0, description="Number of pages with parsed facts")
    rules_evaluated: int = Field(0, description="Number of rule result rows")
    overall_score: Optional[float] = Field(None, description="Overall SEO score (0-100)")
    grade: Optional[str] = Field(None, description="Letter grade")
    output_file_path: Optional[str] = Field(None, description="Path to output JSON file")
    crawl_config_recovered: bool = Field(False, description="Whether crawl config was recovered from defaults due to missing CrawlJob row")
    crawl_config_recovery_note: Optional[str] = Field(None, description="Human-readable note about config recovery if applicable")
    pages_skipped: int = Field(0, description="Number of URLs skipped during crawl (ignore patterns, runtime conditions)")
    skip_breakdown: Optional[Dict[str, int]] = Field(None, description="Skip counts by reason code")
    result: Optional[Union[Dict[str, Any], Any]] = Field(None, description="Completed audit result payload if available")


class StageSummary(BaseModel):
    """Summary of a single pipeline stage."""

    status: str
    count: int = 0
    completed_at: Optional[str] = None


class ParseStageSummary(StageSummary):
    pages_parsed: int = 0
    pages_failed: int = 0
    pages_skipped: int = 0


class EvaluateStageSummary(StageSummary):
    total_results: int = 0
    rules_run: int = 0
    error_count: int = 0


class ScoreStageSummary(StageSummary):
    overall_score: Optional[float] = None
    grade: Optional[str] = None
    total_pages_scored: int = 0
    critical_issues: int = 0
    output_file_path: Optional[str] = None


class PipelineSummaryResponse(BaseModel):
    """Full pipeline summary for an audit."""

    audit_id: str
    audit_id: str
    domain: Optional[str] = None
    parse: ParseStageSummary
    evaluate: EvaluateStageSummary
    score: ScoreStageSummary


class PageScoreDetail(BaseModel):
    """Per-page score details."""

    page_id: str
    url: str
    overall_score: float
    grade: str
    rules_passed: int
    rules_failed: int
    critical_issues: int


# The audit endpoints now return the unified response shape
# (audit, summary, categories, issues, category_results, ...). SeoAnalysisResponse
# is kept as an alias for backward compatibility with existing imports.
SeoAnalysisResponse = UnifiedAuditResponse


class SeoAnalysisSummary(BaseModel):
    """Summary of an analysis run for history listing."""

    audit_id: str
    audit_id: str
    domain: str
    overall_score: float
    grade: str
    total_pages_scored: int
    critical_issues: int
    scored_at: str


class PaginatedAnalyses(BaseModel):
    """Paginated list of analysis runs."""

    total: int
    limit: int
    offset: int
    results: List[SeoAnalysisSummary]


class AnalysisError(BaseModel):
    """Error response for analysis endpoints."""

    success: bool = False
    error: str
    detail: str
