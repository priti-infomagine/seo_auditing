"""
Unified Audit Response Builder.

Single source of truth for the audit response JSON shape. Consolidates the
previously-duplicated assembly logic that lived in AnalysisScorerService,
response_builder.build_per_page_breakdown, and the three audit endpoints.

Pipeline inside this builder:
    RuleEvaluationResult rows (DB)
        -> reconstruct RuleResult[] (per page, homepage weighted)
        -> ScoreCalculator (overall_score / grade / per-category score)
        -> RuleResultToSEOIssueConverter (SEOIssue[] with page_url + affected_part)
        -> assemble unified {audit, summary, categories, issues, ...} dict

The crawler/parser evidence is already persisted (parsed_page_facts, page_seo_data,
page_network_data, crawl_pages); this builder only *reads* it — it never scrapes.
Metrics that the pipeline does not measure are reported with
{available: false, value: null, reason: ...} rather than misleading zeros.
"""
import asyncio
import json
import logging
from collections import defaultdict
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse
from uuid import UUID

import httpx

from app.core.config import settings

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.datetime_utils import to_iso
from app.core.logger import logger
from app.modules.crawler.repositories.crawl_job_repository import CrawlJobRepository
from app.modules.crawler.repositories.page_link_repository import PageLinkRepository
from app.modules.audit.repositories.parsed_page_fact_repository import (
    ParsedPageFactRepository,
)
from app.modules.audit.repositories.rule_evaluation_repository import (
    RuleEvaluationResultRepository,
)
from app.modules.crawler.repositories.crawl_page_repository import CrawlPageRepository
from app.modules.crawler.repositories.page_seo_data_repository import (
    PageSEODataRepository,
)
from app.modules.seprate_checks.robots_check.repository import (
    RobotCheckRepository,
)
from app.modules.rule_engine.models.rule_evidence_map import (
    CATEGORY_DISPLAY,
    CHECK_KEY_TO_RULE_IDS,
    RULE_TITLES,
    RULE_WHY,
    RULE_WHAT,
    SUBCATEGORY_NOT_AVAILABLE,
    SUBCATEGORY_OF,
)
from app.modules.rule_engine.models.rule_result import RuleResult, Severity
from app.modules.rule_engine.models.seo_issue import SEOIssue, SeverityTier
from app.modules.rule_engine.services.issue_factory import (
    RuleResultToSEOIssueConverter,
)
from app.modules.scorer.services.score_calculator import (
    ScoreCalculator,
    get_status,
    PASS_THRESHOLD,
)

logger = logging.getLogger(__name__)


class AuditResponseBuilder:
    """Assembles the unified audit response from persisted DB rows."""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.crawl_job_repo = CrawlJobRepository(db)
        self.crawl_page_repo = CrawlPageRepository(db)
        self.page_link_repo = PageLinkRepository(db)
        self.parsed_fact_repo = ParsedPageFactRepository(db)
        self.rule_eval_repo = RuleEvaluationResultRepository(db)
        self.seo_repo = PageSEODataRepository(db)
        self.robots_repo = RobotCheckRepository(db)
        self.calculator = ScoreCalculator()
        self.converter = RuleResultToSEOIssueConverter()
        from app.modules.scorer.services.scorer_service import ScorerService
        self.rules = ScorerService().rules

    async def build(
        self,
        audit_id: UUID,
        eval_errors: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Build the complete unified audit response.

        Args:
            audit_id: The audit ID (== audit_id), the single tracking key.
            eval_errors: optional list of {page_id, url, error} dicts from the
                evaluation stage (synthetic ERROR rule results are also read
                from DB and included).

        Returns:
            Unified audit response dict matching audit_response_schemas.UnifiedAuditResponse.
        """
        logger.info("AuditResponseBuilder.build: audit_id=%s", audit_id)

        crawl_job = await self.crawl_job_repo.get_by_id(audit_id)
        domain = crawl_job.domain if crawl_job else ""

        robots_check = await self.robots_repo.get_latest_by_domain(domain) if domain else None
        audit_id = _coerce_uuid(audit_id)

        # --- Crawl pages (URL map, status, depth, counts) ---
        crawl_pages = await self.crawl_page_repo.get_by_audit_id(audit_id)
        page_url_map: Dict[UUID, str] = {}
        homepage_ids: set = set()
        status_code_counts: Dict[str, int] = defaultdict(int)
        crawl_redirects = 0
        broken_pages = 0
        crawl_errors = 0
        for p in crawl_pages:
            page_url_map[p.id] = p.url or p.normalized_url
            if p.depth == 0:
                homepage_ids.add(p.id)
            if p.status_code:
                status_code_counts[str(p.status_code)] += 1
            if p.is_error:
                broken_pages += 1
            if p.is_redirect:
                crawl_redirects += 1
            if not p.is_success and not p.is_redirect:
                crawl_errors += 1

        pages_crawled = len([p for p in crawl_pages if p.is_crawled])
        pages_discovered = len(crawl_pages)

        # --- Parsed facts (per-page content/image/schema/link signals) ---
        parsed_facts = await self.parsed_fact_repo.get_by_audit_id(audit_id)

        # --- Rule evaluation results ---
        eval_rows = await self.rule_eval_repo.get_by_audit_id(audit_id)

        # Index eval errors (synthetic ERROR rows + caller-supplied)
        all_errors: List[Dict[str, Any]] = list(eval_errors or [])
        for er in eval_rows:
            if er.severity == Severity.ERROR.value:
                all_errors.append({
                    "rule_id": er.rule_id,
                    "page_id": str(er.page_id),
                    "url": page_url_map.get(er.page_id, str(er.page_id)),
                    "error": er.message,
                })

        # --- Canonical page ingestion (Section 1) -----------------------------
        # Collapse www / non-www + trailing-slash variants of the same logical
        # page into ONE canonical page so issues are never duplicated across the
        # two host variants. If both variants are crawled as separate pages
        # (neither redirects to the other), emit ONE site-level
        # missing_www_redirect issue instead of duplicating every check.
        canonical_of_page: Dict[UUID, str] = {}
        canonical_groups: Dict[str, List[UUID]] = defaultdict(list)
        canonical_url: Dict[str, str] = {}
        www_roots: set = set()
        nonwww_roots: set = set()
        for p in crawl_pages:
            url = p.url or p.normalized_url or ""
            parsed = urlparse(url)
            host = (parsed.hostname or "").lower()
            if not host:
                continue
            host_nw = host[4:] if host.startswith("www.") else host
            if host.startswith("www."):
                www_roots.add(host_nw)
            else:
                nonwww_roots.add(host_nw)
            path = parsed.path or "/"
            if path != "/" and path.endswith("/"):
                path = path.rstrip("/")
            key = f"{host_nw}{path}"
            canonical_of_page[p.id] = key
            if key not in canonical_url:
                canonical_url[key] = url
            canonical_groups[key].append(p.id)

        www_redirect_issue: Optional[SEOIssue] = None
        if www_roots & nonwww_roots:
            # Both www and non-www crawled for the same root -> one advisory issue.
            all_errors.append({
                "rule_id": "missing_www_redirect", "page_id": "",
                "url": "", "error": "Both www and non-www host variants resolve",
            })
            www_redirect_issue = SEOIssue(
                rule_id="missing_www_redirect",
                severity=SeverityTier.LOW,
                category="technical",
                status="failed",
                page_url=domain or "",
                affected_part="canonical",
                evidence={"www_and_nonwww": sorted(www_roots & nonwww_roots)},
                score_impact=0.0,
                message=(
                    "Both www and non-www host variants resolve without a single "
                    "canonical redirect; pick one and 301-redirect the other."
                ),
                recommendation=(
                    "Choose one canonical host (www or non-www) and 301-redirect the other."
                ),
                 page_id=None, audit_id=str(audit_id),
            )

        # Dedupe parsed_facts to one per canonical page so top-level link/image/
        # schema counts reflect the deduped page set (Section 5).
        _seen_canon = set()
        canonical_parsed_facts: List = []
        for f in parsed_facts:
            ck = canonical_of_page.get(f.page_id, str(f.page_id))
            if ck in _seen_canon:
                continue
            _seen_canon.add(ck)
            canonical_parsed_facts.append(f)

        # Group rule results by canonical page (merge underlying page_ids).
        # Within a canonical page, keep ONE result per rule_id (worst verdict wins)
        # so the same check is never duplicated when www + non-www resolve to the
        # same logical page (Section 1).
        canonical_results: Dict[str, Dict[str, RuleResult]] = defaultdict(dict)
        for er in eval_rows:
            if er.severity == Severity.ERROR.value:
                continue  # errors excluded from scoring/issues
            key = canonical_of_page.get(er.page_id, str(er.page_id))
            rule_id = er.rule_id
            new_rr = RuleResult(
                rule_id=rule_id,
                name=er.rule_name,
                category=er.category,
                severity=Severity(er.severity),
                passed=er.passed,
                score_impact=er.score_impact,
                message=er.message,
                recommendation=er.recommendation,
                data=er.rule_data,
                tags=er.tags or [],
            )
            existing = canonical_results[key].get(rule_id)
            if existing is None or (not new_rr.passed and existing.passed):
                canonical_results[key][rule_id] = new_rr
        canonical_results: Dict[str, List[RuleResult]] = {
            k: list(v.values()) for k, v in canonical_results.items()
        }

        total_pages_analyzed = len(canonical_groups)

        # --- Shared check-result cache (Section 2) ----------------------------
        # ONE canonical verdict per (canonical page, check_key). check_key is the
        # subcategory a rule rolls up into (SUBCATEGORY_OF). Multiple rules may map
        # to the same check_key; the worst (failed) verdict wins so the same check
        # can never contradict itself across categories.
        check_cache: Dict[str, Dict[str, bool]] = defaultdict(dict)
        check_rule_ids: Dict[str, set] = defaultdict(set)
        check_cats: Dict[str, set] = defaultdict(set)
        cat_checks: Dict[str, set] = defaultdict(set)
        for key, results in canonical_results.items():
            for r in results:
                sub = SUBCATEGORY_OF.get(r.rule_id, r.rule_id)
                existing = check_cache[key].get(sub)
                if existing is None or not r.passed:
                    check_cache[key][sub] = bool(r.passed)
                check_rule_ids[sub].add(r.rule_id)
                check_cats[sub].add(r.category)
                cat_checks[r.category].add(sub)

        # --- Per-page scoring (homepage weighted 2x) --------------------------
        per_page_scores: List[Dict[str, Any]] = []
        for key, results in canonical_results.items():
            scorable = [r for r in results if r.severity != Severity.ERROR]
            url = canonical_url.get(key, key)
            if scorable:
                page_score = self.calculator.calculate_score(scorable)
            else:
                page_score = {
                    "overall_score": 0.0,
                    "grade": "F",
                    "total_passed": 0,
                    "total_failed": len(results),
                    "critical_issues": 0,
                }
            weight = 2.0 if any(pid in homepage_ids for pid in canonical_groups[key]) else 1.0
            per_page_scores.append({
                "page_id": key,
                "url": url,
                "overall_score": page_score.get("overall_score", 0.0),
                "grade": page_score.get("grade", "F"),
                "weight": weight,
                "results": results,
            })

        # --- Project-level aggregate score ---
        if per_page_scores:
            total_weight = sum(p["weight"] for p in per_page_scores)
            weighted = sum(p["overall_score"] * p["weight"] for p in per_page_scores)
            overall_score = round(weighted / total_weight, 1) if total_weight else 0.0
        else:
            overall_score = 0.0
        grade = self.calculator._get_grade(overall_score)

        # --- Build SEOIssue[] via the centralized converter ---
        all_seo_issues: List[SEOIssue] = []
        for p in per_page_scores:
            for rr in p["results"]:
                issue = self.converter.from_rule_result(
                     rr, page_url=p["url"],
                     page_id=p["page_id"], audit_id=str(audit_id),
                 )
                if issue is not None:
                    all_seo_issues.append(issue)
        if www_redirect_issue is not None:
            all_seo_issues.append(www_redirect_issue)

        # --- Build main-rule verdict cache and per-category main rule sets ---
        rule_cache: Dict[str, Dict[str, bool]] = defaultdict(dict)
        main_rules_per_cat: Dict[str, set] = defaultdict(set)
        for key, results in canonical_results.items():
            for r in results:
                existing = rule_cache[key].get(r.rule_id)
                if existing is None or not r.passed:
                    rule_cache[key][r.rule_id] = bool(r.passed)
                main_rules_per_cat[r.category].add(r.rule_id)

        # --- Assemble sections ---
        summary = self._build_summary(overall_score, all_seo_issues)
        categories = self._build_categories(
            all_seo_issues, main_rules_per_cat, rule_cache, total_pages_analyzed
        )
        issues = await self._build_issues(all_seo_issues)
        crawl = await self._build_crawl_section(
            crawl_job, pages_discovered, pages_crawled, total_pages_analyzed,
            status_code_counts, crawl_redirects, broken_pages, crawl_errors,
            robots_check,
        )
        # Batch-fetch SEO data for all crawl pages once (O(1)) instead of
        # per-page get_by_page_id inside _build_indexation (N+1 fix).
        seo_map = await self.seo_repo.get_by_page_ids(
            [p.id for p in crawl_pages]
        )
        indexation = await self._build_indexation(
            crawl_pages, canonical_parsed_facts, seo_map, robots_check
        )
        performance = await self._build_performance(canonical_parsed_facts)
        structured_data = self._build_structured_data(canonical_parsed_facts)
        links = await self._build_links(canonical_parsed_facts, audit_id)
        images = self._build_images(canonical_parsed_facts)
        content = self._build_content(canonical_parsed_facts)
        external_deps = self._build_external_dependencies()
        errors = all_errors
        metadata = self._build_metadata(
            total_issues=len([i for i in all_seo_issues if i.status == "failed"]),
            total_rules_evaluated=len(self.rules),
        )
        audit = self._build_audit_block(
            crawl_job, audit_id,
            pages_discovered, pages_crawled, total_pages_analyzed,
            crawl, indexation, performance, structured_data,
            links, images, content, external_deps, errors, metadata,
        )

        raw_response = {
            "audit": audit,
            "summary": summary,
            "categories": categories,
            "issues": issues,
        }
        return self._strip_empty(raw_response) or {}

    def _strip_empty(self, data: Any) -> Any:
        """Recursively remove empty data: None, empty lists, and unavailable structs."""
        if isinstance(data, dict):
            # Prune `_unavailable` metrics completely
            if data.get("available") is False and data.get("value") is None:
                return None
            
            cleaned = {}
            for k, v in data.items():
                val = self._strip_empty(v)
                if val is not None and val != []:
                    cleaned[k] = val
            return cleaned if cleaned else None
        elif isinstance(data, list):
            cleaned_list = [self._strip_empty(item) for item in data]
            cleaned_list = [item for item in cleaned_list if item is not None and item != []]
            return cleaned_list if cleaned_list else None
        else:
            return data

    # ------------------------------------------------------------------ summary
    def _build_summary(
        self,
        overall_score: float,
        all_seo_issues: List[SEOIssue],
    ) -> Dict[str, Any]:
        # Normalize rule checks for one main URL: deduplicate by rule_id so
        # the same check is not counted once per page.
        seen_rules: set = set()
        normalized_failed: List[SEOIssue] = []
        normalized_passed: List[SEOIssue] = []
        for i in all_seo_issues:
            key = i.rule_id
            if key in seen_rules:
                continue
            seen_rules.add(key)
            if i.status == "failed":
                normalized_failed.append(i)
            else:
                normalized_passed.append(i)

        failed = normalized_failed
        passed = normalized_passed
        tier_counts = {t.value: 0 for t in SeverityTier}
        for i in failed:
            tier_counts[i.severity.value] += 1

        return {
            "score": overall_score,
            "health": get_status(overall_score),
            "issues": {
                "critical": tier_counts["critical"],
                "high": tier_counts["high"],
                "medium": tier_counts["medium"],
                "low": tier_counts["low"],
                "total": len(normalized_failed),
            },
            "checks": {
                "passed": len(passed),
                "failed": len(failed),
                "total": len(passed) + len(failed),
            },
        }

    # ------------------------------------------------------------------ categories
    def _build_categories(
        self,
        all_seo_issues: List[SEOIssue],
        main_rules_per_cat: Dict[str, set],
        rule_cache: Dict[str, Dict[str, bool]],
        total_pages: int,
    ) -> List[Dict[str, Any]]:
        # Per main rule: pass-rate across canonical pages.
        #   check_score = 100 * pages_passing / total_pages_checked
        #   checks_passed = #main_rules with check_score >= PASS_THRESHOLD
        # categories[].issues carries that category's failed issues;
        # the key is omitted entirely when a category has no failures.
        out: List[Dict[str, Any]] = []
        for cat, display in CATEGORY_DISPLAY.items():
            main_rule_ids = main_rules_per_cat.get(cat, set())
            checks_total = len(main_rule_ids)
            check_scores: List[float] = []
            checks_passed = 0
            for rule_id in main_rule_ids:
                passed_pages = sum(
                    1 for ck in rule_cache
                    if rule_cache[ck].get(rule_id) is not False
                )
                check_score = round(100.0 * passed_pages / total_pages, 1) if total_pages else 0.0
                check_scores.append(check_score)
                if check_score >= PASS_THRESHOLD:
                    checks_passed += 1
            checks_failed = checks_total - checks_passed
            category_score = round(sum(check_scores) / len(check_scores), 1) if check_scores else 0.0
            entry: Dict[str, Any] = {
                "id": display["id"],
                "name": display["name"],
                "score": category_score,
                "status": get_status(category_score),
                "checks_total": checks_total,
                "checks_passed": checks_passed,
                "checks_failed": checks_failed,
            }
            out.append(entry)
        return out

    def _make_hashable(self, val: Any) -> str:
        try:
            return json.dumps(val, sort_keys=True)
        except Exception:
            return str(val)

    async def _generate_ollama_recommendation(
        self,
        title: str,
        what: Optional[str] = None,
        why: Optional[str] = None,
        default_rec: Optional[str] = None,
        client: Optional[httpx.AsyncClient] = None,
        semaphore: Optional[asyncio.Semaphore] = None,
    ) -> Optional[str]:
        prompt = (
            f"You are an expert technical SEO auditor. Write a single clear, actionable, professional recommendation "
            f"(1-2 sentences max) to fix the following issue.\n"
            f"Issue Title: {title}\n"
        )
        if what:
            prompt += f"Problem (What): {what}\n"
        if why:
            prompt += f"Impact (Why): {why}\n"
        prompt += "Do not include conversational intros or extra text. Provide ONLY the recommendation statement."

        async def _call():
            try:
                url = f"{settings.OLLAMA_BASE_URL.rstrip('/')}/api/generate"
                payload = {
                    "model": settings.OLLAMA_MODEL,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.2,
                        "num_predict": 100,
                    },
                }
                if client:
                    resp = await client.post(url, json=payload, timeout=min(10.0, float(settings.OLLAMA_TIMEOUT)))
                else:
                    async with httpx.AsyncClient() as c:
                        resp = await c.post(url, json=payload, timeout=min(10.0, float(settings.OLLAMA_TIMEOUT)))

                if resp.status_code == 200:
                    data = resp.json()
                    text = data.get("response", "").strip()
                    if text:
                        return text
            except Exception as e:
                logger.warning("Ollama recommendation generation skipped/failed for %r: %s", title, e)
            return default_rec or None

        if semaphore:
            async with semaphore:
                return await _call()
        return await _call()

    def _extract_locations(self, group: List[SEOIssue]) -> List[Dict[str, Any]]:
        locations = []
        for issue in group:
            if not issue.evidence or not isinstance(issue.evidence, dict):
                continue
            
            sample_items = None
            for key in ("sample", "samples", "items", "issues", "urls", "broken_samples", "missing"):
                val = issue.evidence.get(key)
                if isinstance(val, list) and val:
                    sample_items = val
                    break

            if sample_items:
                for item in sample_items:
                    loc = {"page_url": issue.page_url}
                    if isinstance(item, dict):
                        loc.update(item)
                    else:
                        loc["target"] = str(item)
                    locations.append(loc)
            else:
                filtered = {
                    k: v for k, v in issue.evidence.items()
                    if k not in ("total_count", "without_alt", "coverage", "total_broken", "mixed_content_count", "word_count", "h1_count", "score_impact")
                }
                if filtered:
                    loc = {"page_url": issue.page_url}
                    loc.update(filtered)
                    locations.append(loc)
        return locations

    # ------------------------------------------------------------------ issues
    async def _build_issues(self, all_seo_issues: List[SEOIssue]) -> List[Dict[str, Any]]:
        by_rule: Dict[str, List[SEOIssue]] = defaultdict(list)
        for i in all_seo_issues:
            if i.status == "failed":
                by_rule[i.rule_id].append(i)

        out: List[Dict[str, Any]] = []
        for rule_id, group in by_rule.items():
            first = group[0]
            seen_urls: set = set()
            occurrence_map = {}
            for issue in group:
                if issue.page_url in seen_urls:
                    continue
                seen_urls.add(issue.page_url)
                
                key = self._make_hashable(issue.current_value)
                if key not in occurrence_map:
                    occurrence_map[key] = {
                        "current_value": issue.current_value
                    }

            occurrences = list(occurrence_map.values())
            locations = self._extract_locations(group)

            issue_obj = {
                "rule_id": rule_id,
                "category": first.category,
                "severity": first.severity.value,
                "title": RULE_TITLES.get(rule_id, rule_id),
                "affected_pages": len(seen_urls),
                "occurrences": occurrences,
            }
            if locations:
                issue_obj["evidence"] = {"locations": locations[:50]}  # cap to top 50 sample locations per issue
            elif first.evidence:
                issue_obj["evidence"] = first.evidence

            if RULE_WHY.get(rule_id):
                issue_obj["why"] = RULE_WHY.get(rule_id)
            if RULE_WHAT.get(rule_id):
                issue_obj["what"] = RULE_WHAT.get(rule_id)
            if first.recommendation:
                issue_obj["recommendation"] = first.recommendation

            out.append(issue_obj)

        # Concurrently request LLM recommendations from Ollama for unique issues
        sem = asyncio.Semaphore(3)
        try:
            async with httpx.AsyncClient() as client:
                tasks = [
                    self._generate_ollama_recommendation(
                        title=item["title"],
                        what=item.get("what"),
                        why=item.get("why"),
                        default_rec=item.get("recommendation"),
                        client=client,
                        semaphore=sem,
                    )
                    for item in out
                ]
                recs = await asyncio.gather(*tasks, return_exceptions=True)
                for item, rec in zip(out, recs):
                    if isinstance(rec, str) and rec:
                        item["recommendation"] = rec
        except Exception as err:
            logger.warning("Failed to generate LLM recommendations via Ollama: %s", err)

        out.sort(key=lambda x: _tier_priority(SeverityTier(x.get("severity", "info"))))
        return out



    # ------------------------------------------------------------- crawl stats
    async def _build_crawl_section(
        self,
        crawl_job,
        pages_discovered: int,
        pages_crawled: int,
        pages_analyzed: int,
        status_code_counts: Dict[str, int],
        redirect_count: int,
        broken_pages: int,
        crawl_errors: int,
        robots_check=None,
    ) -> Dict[str, Any]:
        started_at = to_iso(crawl_job.created_at) if crawl_job else None
        completed_at = to_iso(crawl_job.completed_at) if crawl_job else None
        return {
            "pages_discovered": pages_discovered,
            "pages_crawled": pages_crawled,
            "pages_analyzed": pages_analyzed,
            "blocked_by_robots": _robots_blocked_info(robots_check),
            "redirects": redirect_count,
            "broken_pages": broken_pages,
            "orphan_pages": _unavailable("link_graph_analysis_not_implemented"),
            "crawl_errors": crawl_errors,
            "status_codes": dict(status_code_counts),
            "started_at": started_at,
            "completed_at": completed_at,
        }

    # ---------------------------------------------------------- indexation
    async def _build_indexation(
        self,
        crawl_pages: List,
        parsed_facts: List,
        seo_map: Dict | None = None,
        robots_check=None,
    ) -> Dict[str, Any]:
        noindex_pages: set = set()
        canonical_pages: set = set()
        for p in crawl_pages:
            seo = seo_map.get(p.id) if seo_map else await self.seo_repo.get_by_page_id(p.id)
            if seo is None:
                continue
            robots = (seo.robots_meta or "").lower()
            if "noindex" in robots:
                noindex_pages.add(p.id)
            if seo.canonical:
                canonical_pages.add(p.id)
        total = len(crawl_pages)
        indexable = total - len(noindex_pages)
        return {
            "indexable": indexable,
            "noindex": len(noindex_pages),
            "canonicalized": len(canonical_pages),
            "blocked_by_robots": _robots_blocked_info(robots_check),
            "not_indexable": len(noindex_pages),
        }
    async def _build_performance(self, parsed_facts: List) -> Dict[str, Any]:
        ttfb_ms_values = []
        for fact in parsed_facts:
            page_facts = fact.page_facts or {}
            rt = page_facts.get("response_time_ms")
            if rt and rt > 0:
                ttfb_ms_values.append(rt)
        ttfb_value = (
            round(sum(ttfb_ms_values) / len(ttfb_ms_values), 1) if ttfb_ms_values else None
        )
        ttfb = {
            "available": ttfb_value is not None,
            "value": ttfb_value,
            "unit": "milliseconds",
                "status": get_status(_ttbf_bucket(ttfb_value)) if ttfb_value else "unknown",
            "reason": None if ttfb_value else "response_time_ms_not_available",
        }
        return {
            "available": ttfb_value is not None,
            "core_web_vitals": _unavailable("browser_performance_measurement_not_available"),
            "ttfb": ttfb,
        }

    # --------------------------------------------------------- structured_data
    def _build_structured_data(self, parsed_facts: List) -> Dict[str, Any]:
        type_counts: Dict[str, int] = defaultdict(int)
        with_schema = 0
        without_schema = 0
        valid = 0
        invalid = 0
        for fact in parsed_facts:
            parsed_data = fact.parsed_data or {}
            schemas = parsed_data.get("schemas", []) or []
            if schemas:
                with_schema += 1
                valid += len(schemas)  # parsed OK → treat as valid instances
            else:
                without_schema += 1
                invalid += 1  # no schema present = invalid for this check
            for s in schemas:
                t = None
                if isinstance(s, dict):
                    t = s.get("type") or s.get("@type")
                    if not t and isinstance(s.get("types"), list) and s["types"]:
                        t = s["types"][0]
                    if not t and isinstance(s.get("parsed"), dict):
                        t = s["parsed"].get("@type") or s["parsed"].get("type")
                if t:
                    type_counts[str(t)] += 1
        return {
            "pages_with_schema": with_schema,
            "pages_without_schema": without_schema,
            "valid": valid,
            "invalid": invalid,
            "types": dict(type_counts),
        }

    # ------------------------------------------------------------------- links
    async def _build_links(self, parsed_facts: List, audit_id) -> Dict[str, Any]:
        internal = 0
        external = 0
        total = 0
        for fact in parsed_facts:
            parsed_data = fact.parsed_data or {}
            links = parsed_data.get("links") or {}
            if isinstance(links, dict):
                internal += int(links.get("internal_count", 0) or 0)
                external += int(links.get("external_count", 0) or 0)
                total += int(links.get("total_links", 0) or 0)
            elif isinstance(links, list):
                for link in links:
                    if not isinstance(link, dict):
                        continue
                    total += 1
                    is_ext = (
                        link.get("link_type") == "external"
                        or link.get("is_external", False)
                    )
                    if is_ext:
                        external += 1
                    else:
                        internal += 1

        broken_counts = await self.page_link_repo.get_broken_counts(audit_id)
        broken_internal = broken_counts.get("broken_internal", 0)
        broken_external = broken_counts.get("broken_external", 0)

        return {
            "internal": {
                "total": internal,
                "broken": {"available": True, "value": broken_internal},
            },
            "external": {
                "total": external,
                "broken": {"available": True, "value": broken_external},
            },
            "orphan_pages": _unavailable("link_graph_analysis_not_implemented"),
            "total_links": total,
        }

    # ------------------------------------------------------------------ images
    def _build_images(self, parsed_facts: List) -> Dict[str, Any]:
        total = 0
        missing_alt = 0
        empty_alt = 0
        missing_dimensions = 0
        oversized = 0
        modern_format = 0
        lazy_loading = 0
        for fact in parsed_facts:
            parsed_data = fact.parsed_data or {}
            images = parsed_data.get("images") or {}
            if isinstance(images, dict):
                # rule_evaluator stores a summary: {total_count, without_alt, sample:[...]}
                total += int(images.get("total_count", 0) or 0)
                missing_alt += int(images.get("without_alt", 0) or 0)
                for img in images.get("sample", []) or []:
                    if not isinstance(img, dict):
                        continue
                    if not img.get("width") and not img.get("height"):
                        missing_dimensions += 1
                    fmt = (img.get("format") or img.get("url", "") or "").lower()
                    if any(ext in fmt for ext in (".webp", ".avif", ".heic")):
                        modern_format += 1
                    if (img.get("loading") or "").strip().lower() == "lazy":
                        lazy_loading += 1
                    size = img.get("file_size") or 0
                    if isinstance(size, (int, float)) and size > 100 * 1024:
                        oversized += 1
            elif isinstance(images, list):
                for img in images:
                    if not isinstance(img, dict):
                        continue
                    total += 1
                    alt = img.get("alt", "")
                    if not alt or (isinstance(alt, str) and not alt.strip()):
                        missing_alt += 1
                    elif isinstance(alt, str) and alt.strip() == "":
                        empty_alt += 1
                    if not img.get("width") and not img.get("height"):
                        missing_dimensions += 1
                    fmt = (img.get("format") or img.get("url", "") or "").lower()
                    if any(ext in fmt for ext in (".webp", ".avif", ".heic")):
                        modern_format += 1
                    if (img.get("loading") or "").strip().lower() == "lazy":
                        lazy_loading += 1
                    size = img.get("file_size") or 0
                    if isinstance(size, (int, float)) and size > 100 * 1024:
                        oversized += 1
        return {
            "total": total,
            "missing_alt": missing_alt,
            "empty_alt": empty_alt,
            "missing_dimensions": missing_dimensions,
            "oversized": oversized,
            "modern_format": modern_format,
            "lazy_loading": lazy_loading,
        }

    # ------------------------------------------------------------------ content
    def _build_content(self, parsed_facts: List) -> Dict[str, Any]:
        thin_pages = 0
        content_hashes: Dict[str, int] = defaultdict(int)
        for fact in parsed_facts:
            page_facts = fact.page_facts or {}
            word_count = page_facts.get("word_count", 0) or 0
            if word_count < 300:
                thin_pages += 1
            h = page_facts.get("content_hash")
            if h:
                content_hashes[h] += 1
        # duplicate_pages = number of pages that share a content_hash with >=1 other page
        duplicate_groups = [c for c in content_hashes.values() if c > 1]
        duplicate_pages = sum(duplicate_groups)
        return {
            "thin_pages": thin_pages,
            "duplicate_pages": duplicate_pages,
            "duplicate_groups": len(duplicate_groups),
            "near_duplicate_pages": _unavailable("content_similarity_analysis_not_implemented"),
            "missing_author": _unavailable("author_extraction_not_implemented"),
            "outdated_pages": _unavailable("content_freshness_tracking_not_implemented"),
        }



    # --------------------------------------------------------- external deps
    def _build_external_dependencies(self) -> List[Dict[str, Any]]:
        return [
            {"feature": "Core Web Vitals (LCP/INP/CLS)", "status": "not_available",
             "reason": "browser_performance_measurement_not_available"},
            {"feature": "Backlink analysis", "status": "not_available",
             "reason": "backlink_data_provider_not_configured"},
            {"feature": "Keyword search volume / SERP data", "status": "not_available",
             "reason": "keyword_serp_data_provider_not_configured"},
            {"feature": "Google Search Console", "status": "not_available",
             "reason": "not_connected"},
        ]

    # ---------------------------------------------------------------- metadata
    def _build_metadata(self, total_issues: int, total_rules_evaluated: int) -> Dict[str, Any]:
        return {
            "crawler_version": _version("crawler"),
            "parser_version": _version("parser"),
            "rule_engine_version": "1.0.0",
            "rules_executed": total_rules_evaluated,
            "total_issues": total_issues,
            "output_shape": "unified_v1",
        }

    # --------------------------------------------------------------- audit blk
    def _build_audit_block(
        self, crawl_job, audit_id,
        pages_discovered, pages_crawled, pages_analyzed,
        crawl_stats, indexation, performance, structured_data,
        links, images, content, external_deps, errors, metadata,
    ) -> Dict[str, Any]:
        return {
            "audit_id": str(audit_id),
            "url": crawl_job.url if crawl_job else None,
            "domain": crawl_job.domain if crawl_job else None,
            "started_at": crawl_job.created_at if crawl_job else None,
            "completed_at": crawl_job.completed_at if crawl_job else None,
            "status": crawl_job.status if crawl_job else None,
            "pages": {
                "discovered": pages_discovered,
                "crawled": pages_crawled,
                "analyzed": pages_analyzed,
            },
            "crawl_stats": crawl_stats,
            "indexation": indexation,
            "performance": performance,
            "structured_data": structured_data,
            "links": links,
            "images": images,
            "content": content,
            "external_dependencies": external_deps,
            "errors": errors,
            "meta": metadata,
        }


# ===================================================================== helpers

def _coerce_uuid(value) -> UUID:
    """Return value as UUID if possible, else pass through."""
    from uuid import UUID
    if isinstance(value, UUID):
        return value
    try:
        return UUID(str(value))
    except Exception:
        return value


def _unavailable(reason: str) -> Dict[str, Any]:
    """Spec §17/#21: never report 0 for not-measured metrics."""
    return {"available": False, "value": None, "reason": reason}


def _robots_blocked_info(robots_check) -> Dict[str, Any]:
    """Convert the persisted robots check into a stable metric shape.

    The robots check measures site-level directives, not a per-page blocked
    count. A value of 1 therefore means the wildcard rules block the whole
    site; 0 means the checked robots file does not block the whole site.
    """
    if robots_check is None:
        return _unavailable("robots_check_not_run")

    fetch_status = getattr(robots_check.fetch_status, "value", robots_check.fetch_status)
    if fetch_status != "success":
        return _unavailable(
            f"robots_txt_fetch_{fetch_status or 'unknown'}"
        )

    blocked = bool(getattr(robots_check, "blocks_entire_site", False))
    return {
        "available": True,
        "value": 1 if blocked else 0,
        "reason": (
            "Wildcard robots.txt rules block the entire site"
            if blocked
            else "No site-wide wildcard block detected in robots.txt"
        ),
    }


def _classify_images(evidence: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Classify images from rule evidence into has_alt / missing_alt buckets."""
    sample = evidence.get("sample") if isinstance(evidence, dict) else []
    if not sample:
        return []
    result: List[Dict[str, Any]] = []
    for img in sample:
        if not isinstance(img, dict):
            continue
        alt = img.get("alt", "")
        result.append({
            "src": img.get("src", img.get("url", "")),
            "has_alt": bool((alt or "").strip()),
            "alt_text": alt if alt else None,
        })
    return result


def _health_from_score(score: float) -> str:
    # Kept as a thin delegate so any legacy caller stays consistent with the
    # single authoritative status helper (Section 4).
    return get_status(score)


def _tier_priority(tier: SeverityTier) -> int:
    return {SeverityTier.CRITICAL: 1, SeverityTier.HIGH: 2,
            SeverityTier.MEDIUM: 3, SeverityTier.LOW: 4}.get(tier, 5)


def _ttbf_bucket(ttfb_ms: Optional[float]) -> float:
    """Map a TTFB to a 0-100 health score for the ttfb.status field."""
    if not ttfb_ms:
        return 0.0
    if ttfb_ms < 200:
        return 100.0
    if ttfb_ms < 500:
        return 90.0
    if ttfb_ms < 1000:
        return 70.0
    if ttfb_ms < 2000:
        return 50.0
    return 20.0


def _group_results_by_category(page_rule_results: Dict[UUID, List[RuleResult]]) -> Dict[str, List[RuleResult]]:
    out: Dict[str, List[RuleResult]] = defaultdict(list)
    for results in page_rule_results.values():
        for r in results:
            out[r.category].append(r)
    return out



def _version(module: str) -> str:
    """Return the package version if tracked, else 'unknown' (no fabrication)."""
    try:
        mod = __import__(f"app.modules.{module}", fromlist=[module])
        return getattr(mod, "__version__", "unknown")
    except Exception:
        return "unknown"


