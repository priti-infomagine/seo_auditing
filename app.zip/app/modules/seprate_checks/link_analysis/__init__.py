"""Standalone link analysis API."""
