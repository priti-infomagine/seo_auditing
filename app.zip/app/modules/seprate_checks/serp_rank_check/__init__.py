"""SERP rank check module."""
