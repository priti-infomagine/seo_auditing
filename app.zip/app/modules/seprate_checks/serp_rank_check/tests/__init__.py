"""SERP rank check tests."""
