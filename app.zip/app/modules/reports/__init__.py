"""
Reports package init.
"""
