import asyncio
from datetime import datetime

from uuid import UUID, uuid4

from app.core.datetime_utils import utc_now
from app.core.database import async_session_factory
from app.core.logger import logger
from app.modules.crawler.models.crawl_jobs import CrawlJob
from app.modules.crawler.repositories.crawl_job_repository import CrawlJobRepository
from app.modules.crawler.services.crawl_orchestrator import CrawlOrchestrator
from app.shared.tasks.celery_app import celery_app
from app.shared.tasks.db import run_async
from app.shared.utils.url_utils import get_domain


@celery_app.task(
    name="crawler.crawl_website",
    queue="crawler",
    bind=True,
    # Only auto-retry on transient infrastructure failures (DB / Redis
    # connectivity). Application-level errors — including the historical
    # "CrawlJob not found" — must NOT be retried because the row will not
    # appear between retries; instead the task self-heals by recreating
    # the row from the task arguments.
    autoretry_for=(ConnectionError, TimeoutError, OSError),
    retry_backoff=True,
    retry_backoff_max=300,
    retry_jitter=True,
    max_retries=3,
    acks_late=True,
    time_limit=3600,
    soft_time_limit=3300,
    track_started=True,
)
def crawl_website(self, audit_id: str, url: str, user_id: str, force: bool = False) -> dict:
    logger.info(
        f"crawler.crawl_website: task started for audit_id={audit_id}, url={url}, "
        f"user_id={user_id}"
    )
    task_id = self.request.id

    async def _run():
        crawl_uuid = UUID(audit_id)
        try:
            user_uuid = UUID(user_id)
        except (ValueError, TypeError):
            # Some enqueue paths use a placeholder user_id; we still need
            # *some* valid UUID for the FK on the recreated row.
            user_uuid = uuid4()
        async with async_session_factory() as db:
            job_repo = CrawlJobRepository(db)
            job = await job_repo.get_by_id(crawl_uuid)

            if job is None:
                # The CrawlJob row was missing. This can happen when the
                # DB was reset between POST /audit/analyze and the worker
                # picking up the task, or when a previous attempt inserted
                # the task but failed to commit the row.
                # We self-heal: create a fresh row from the task args
                # with safe defaults so the rest of the pipeline (and the
                # audit pipeline it eventually fires) can find it.
                logger.warning(
                    f"crawler.crawl_website: CrawlJob {audit_id} not found; "
                    f"recreating from task args (url={url}, user_id={user_id})"
                )
                domain = get_domain(url) or ""
                job = CrawlJob(
                    id=crawl_uuid,
                    user_id=user_uuid,
                    url=url,
                    domain=domain,
                    status="queued",
                    max_pages=100,
                    max_depth=5,
                    crawl_config={
                        # Conservative defaults — the original POST
                        # likely specified tighter limits but we can't
                        # know them; the user will get a small crawl.
                        "max_depth": 5,
                        "max_pages": 100,
                        "concurrency": 5,
                        "request_timeout": 60,
                        "delay_ms": 0,
                        "follow_redirects": True,
                        "respect_robots": True,
                        "auto_analyze": True,
                    },
                    crawl_config_recovered=True,
                )
                await job_repo.create(job)
                await db.commit()
                # Re-fetch so any lazy/defaulted fields are populated
                job = await job_repo.get_by_id(crawl_uuid)

            if job.status not in ("queued", "crawling"):
                # Already completed / failed / cancelled — nothing to do.
                return {"status": job.status, "audit_id": audit_id}

            def _progress_callback(current_page: int, total_pages: int | None):
                if not task_id:
                    return
                total = total_pages or 0
                percent = min(100, int((current_page / total) * 100)) if total else 0
                meta = {
                    "current": current_page,
                    "total": total,
                    "percent": percent,
                    "audit_id": audit_id,
                }
                # Throttle: only write to the Redis result backend every 10
                # pages (or on completion at 100%).  update_state() is a
                # synchronous Redis HSET — calling it on every page would
                # block the event loop ~100 times per crawl.
                if 0 < current_page % 10 != 0 and percent < 100:
                    return
                # Offload the synchronous Redis write to a thread so the
                # event loop stays responsive.  fire-and-forget: we don't
                # need to wait for the result backend to confirm.
                try:
                    loop = asyncio.get_running_loop()
                    asyncio.create_task(
                        asyncio.to_thread(
                            self.update_state,
                            task_id=task_id,
                            state="PROGRESS",
                            meta=meta,
                        )
                    )
                except RuntimeError:
                    # No running loop (e.g. tests) — fall back to sync call
                    self.update_state(
                        task_id=task_id, state="PROGRESS", meta=meta
                    )

            try:
                cfg = job.crawl_config or {}
                orchestrator = CrawlOrchestrator(db, crawl_uuid)
                result = await orchestrator.run(
                    start_url=url,
                    max_depth=cfg.get("max_depth", 5),
                    max_pages=cfg.get("max_pages", 1000),
                    concurrency=cfg.get("concurrency", 10),
                    timeout_seconds=cfg.get("request_timeout", 30),
                    delay_ms=cfg.get("delay_ms", 0),
                    follow_redirects=cfg.get("follow_redirects", True),
                    respect_robots=cfg.get("respect_robots", True),
                    user_agent=cfg.get("user_agent"),
                    progress_callback=_progress_callback,
                )

                # Fire auto-analyze pipeline if requested
                if cfg.get("auto_analyze"):
                    await db.commit()

                    logger.info(
                        f"crawler.crawl_website: auto_analyze fired for "
                        f"audit_id={audit_id}, force={force}"
                    )

                    # Fire the analysis pipeline asynchronously.
                    # send_task is a synchronous Redis operation — offload to
                    # a thread so it doesn't block the worker's event loop.
                    await asyncio.to_thread(
                        celery_app.send_task,
                        "audit.run_analysis_pipeline",
                        args=[str(crawl_uuid)],
                        kwargs={"force": force},
                        queue="audit",
                    )
                    result["auto_analyze"] = True

                if task_id:
                    self.update_state(
                        task_id=task_id,
                        state="SUCCESS",
                        meta={
                            "current": job.total_pages or 0,
                            "total": job.total_pages or 0,
                            "percent": 100,
                            "audit_id": audit_id,
                        },
                    )
                logger.info(
                    f"crawler.crawl_website: task succeeded for audit_id={audit_id}, "
                    f"pages_crawled={result.get('pages_crawled')}"
                )
                return result
            except Exception as exc:
                await _mark_failed(db, crawl_uuid, str(exc))
                logger.error(
                    f"crawler.crawl_website: task failed for audit_id={audit_id}: {exc}",
                    exc_info=True,
                )
                raise

    return run_async(_run())


async def _mark_failed(db, crawl_uuid: UUID, error_message: str) -> None:
    job_repo = CrawlJobRepository(db)
    job = await job_repo.get_by_id(crawl_uuid)
    if job and job.status not in ("completed", "failed", "cancelled"):
        job.status = "failed"
        job.error = error_message[:1024]
        job.completed_at = utc_now()
        job.progress_percent = 100
        await job_repo.update(job)
