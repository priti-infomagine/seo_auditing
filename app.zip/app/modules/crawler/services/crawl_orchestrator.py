"""
Crawl orchestrator - controls the entire crawl lifecycle using CrawlScheduler.

Orchestrates all services to perform a complete recursive crawl:
   1. Initialize CrawlJob
   2. Seed CrawlScheduler with start URL
   3. Dynamic worker pool with dual semaphores (http_concurrency / browser_concurrency)
   4. For every URL: page_crawl_service -> page_extraction_service -> persist
   5. Discovered links are submitted back to the scheduler during worker execution
   6. Update CrawlJob status on completion
"""
import asyncio
import hashlib
import time
from typing import Optional
from urllib.parse import urlparse
from uuid import UUID

from app.core.database import async_session_factory
from app.core.datetime_utils import utc_now
from app.core.logger import logger
from app.modules.crawler.models.crawl_jobs import CrawlJob
from app.modules.crawler.models.crawl_pages import CrawlPage
from app.modules.crawler.models.crawl_site_data import CrawlSiteData
from app.modules.crawler.models.page_seo_data import PageSEOData
from app.modules.crawler.models.page_network_data import PageNetworkData
from app.modules.crawler.repositories.crawl_job_repository import CrawlJobRepository
from app.modules.crawler.services.crawl_scheduler import CrawlScheduler
from app.modules.crawler.services.crawl_persistence_service import CrawlPersistenceService
from app.modules.crawler.services.crawl_pipeline_events import CrawlPipelineBus, CrawlPipelineEvent
from app.modules.crawler.services.link_analysis_service import LinkAnalysisService, LinkAnalysisResult
from app.modules.crawler.services.page_crawl_service import PageCrawlService, PageCrawlResult
from app.modules.crawler.services.page_extraction_service import PageExtractionService, PageFacts
from app.modules.crawler.services.redirect_service import RedirectService
from app.modules.crawler.services.site_discovery_service import SiteDiscoveryService
from app.modules.crawler.services.robots_service import RobotsPolicy
from app.modules.crawler.services.technical_analysis_service import TechnicalAnalysisService
from app.modules.crawler.services.url_ignore_service import UrlIgnoreService
from app.modules.crawler.config import CrawlConfig
from app.modules.crawler.types import DiscoveredURL
from app.shared.utils.url_utils import get_domain, is_same_site, normalize_host, normalize_url
from app.modules.crawler.utils.url_classifier import strip_tracking_params


class CrawlOrchestrator:
    """Orchestrates the entire crawl lifecycle using CrawlScheduler."""

    def __init__(self, db, crawl_job_id: UUID):
        self.db = db
        self.crawl_job_id = crawl_job_id
        self.job_repository = CrawlJobRepository(db)
        self.persistence = CrawlPersistenceService(db, crawl_job_id)
        self.page_crawl_service = PageCrawlService()
        self.page_extraction_service = PageExtractionService()
        self.link_analysis_service = LinkAnalysisService
        self.technical_analysis_service = TechnicalAnalysisService
        self.redirect_service_factory = lambda page_id: RedirectService(db, page_id)
        self.config: Optional[CrawlConfig] = None
        self.event_bus = CrawlPipelineBus()
        self._scheduler: Optional[CrawlScheduler] = None
        self._progress_callback: Optional[callable] = None
        self._ignore_service: Optional[UrlIgnoreService] = None
        self._preselected_urls: Optional[set[str]] = None
        self._restrict_to_preselected = False

    async def run(
        self,
        start_url: str,
        max_depth: int = 5,
        max_pages: int = 1000,
        concurrency: int = 10,
        timeout_seconds: int = 30,
        delay_ms: int = 0,
        follow_redirects: bool = True,
        respect_robots: bool = True,
        user_agent: Optional[str] = None,
        progress_callback: Optional[callable] = None,
        preflight_site_result=None,
        preselected_urls: Optional[list[str]] = None,
        restrict_to_preselected: bool = False,
    ) -> dict:
        """
        Run a full recursive crawl using CrawlScheduler dynamic worker pool.

        Terminates when queue is empty AND active_workers == 0,
        ensuring all dynamically discovered URLs are crawled.
        """
        start_time = time.time()
        await self._mark_running()

        job = await self.job_repository.get_by_id(self.crawl_job_id)
        if not job:
            raise ValueError(f"CrawlJob {self.crawl_job_id} not found")

        raw_config = job.crawl_config or {}
        self.config = CrawlConfig.from_dict(raw_config)
        self.persistence.set_flush_every(self.config.write_buffer_flush_every)
        self._progress_callback = progress_callback
        job.total_pages = self.config.max_pages
        await self.job_repository.update(job)

        start_domain = get_domain(start_url)
        site_result = None

        await self.event_bus.emit(
            CrawlPipelineEvent.SCHEDULER_START,
            audit_id=str(self.crawl_job_id),
            start_url=start_url,
            max_depth=self.config.max_depth,
            max_pages=self.config.max_pages,
        )

        if respect_robots:
            if preflight_site_result is not None:
                site_result = preflight_site_result
            else:
                discovery = SiteDiscoveryService(
                    start_url,
                    timeout=timeout_seconds,
                    max_child_sitemaps=self.config.max_sitemap_files,
                    max_urls_per_sitemap=self.config.max_sitemap_page_urls,
                    max_total_page_urls=self.config.max_sitemap_page_urls,
                    max_sitemap_index_depth=self.config.max_sitemap_index_depth,
                )
                site_result = await discovery.discover()
            await self.persistence.persist_site_data(
                CrawlSiteData(
                    crawl_job_id=self.crawl_job_id,
                    robots={
                        "exists": site_result.robots.exists,
                        "status_code": site_result.robots.status_code,
                        "user_agents": {"*": {"allow": [], "disallow": []}},
                        "sitemaps": site_result.robots.sitemap_references,
                    },
                    sitemaps={
                        "exists": len(site_result.sitemaps) > 0,
                        "files": [
                            {
                                "url": s.url,
                                "status_code": s.status_code,
                                "type": "sitemap",
                                "url_count": len(s.urls),
                            }
                            for s in site_result.sitemaps
                        ],
                    },
                )
            )

        # Initialize ignore service and load global patterns
        self._ignore_service = UrlIgnoreService(self.db)
        if self.db:
            await self._ignore_service.load_patterns(self.db, "global")

        self._preselected_urls = (
            {normalize_url(candidate) for candidate in preselected_urls}
            if preselected_urls
            else None
        )
        self._restrict_to_preselected = restrict_to_preselected

        scheduler = CrawlScheduler(
            config=self.config,
            worker_func=self._crawl_page,
            base_domain=start_domain,
            ignore_service=self._ignore_service,
            audit_id=self.crawl_job_id,
        )
        self._scheduler = scheduler

        # Attach robots policy so the scheduler can enforce and record blocks.
        if respect_robots and site_result and site_result.robots.content:
            robots_policy = RobotsPolicy(site_result.robots.content)
            scheduler.set_robots_policy(robots_policy)
            logger.info(
                "Robots policy attached to scheduler for %s (sitemaps: %d)",
                start_domain,
                len(site_result.robots.sitemap_references),
            )

        scheduler.submit_seed(start_url)
        logger.info(
            "Crawl started: %s (max_pages=%d, max_depth=%d)",
            start_url,
            self.config.max_pages,
            self.config.max_depth,
        )

        # Submit sitemap-discovered page URLs into the crawl queue so they
        # participate in the same safety checks as link-discovered URLs.
        sitemap_urls = (
            preselected_urls
            if preselected_urls is not None
            else site_result.discovered_urls
            if site_result
            else []
        )
        if sitemap_urls:
            sitemap_submitted = scheduler.submit_sitemap_urls(
                sitemap_urls,
                source_url=start_url,
            )
            logger.info(
                f"Submitted {sitemap_submitted} sitemap URLs to crawl queue "
                f"(total selected: {len(sitemap_urls)})"
            )
            await self._update_progress(0)

        try:
            await scheduler.run()
        except Exception as exc:
            await self._mark_failed(str(exc))
            # Persist skip records even on failure
            if self.db and self._ignore_service and hasattr(scheduler, "skipped_urls"):
                for url, normalized_url, reason, scope in scheduler.skipped_urls:
                    try:
                        await self._ignore_service.log_skip(
                            self.crawl_job_id,
                            url,
                            normalized_url,
                            reason,
                            scope,
                        )
                    except Exception as skip_exc:  # noqa: BLE001
                        logger.warning(
                            "Failed to persist skip record for %s: %s",
                            url, skip_exc,
                        )
                await self.db.commit()
            return {
                "status": "failed",
                "audit_id": str(self.crawl_job_id),
                "pages_skipped": getattr(scheduler, "pages_skipped_count", 0),
            }
        finally:
            await self.persistence.flush_all()
            pages_crawled_count = scheduler.pages_crawled_count
            pages_discovered_count = scheduler.pages_discovered_count
            self._scheduler = None

        # Persist final counts to CrawlJob
        job = await self.job_repository.get_by_id(self.crawl_job_id)
        if job:
            job.pages_crawled = pages_crawled_count
            job.pages_discovered = pages_discovered_count
            job.pages_skipped = getattr(scheduler, "pages_skipped_count", 0)
            await self.job_repository.update(job)

        # Persist skip records to DB
        if self.db and self._ignore_service and hasattr(scheduler, "skipped_urls"):
            for url, normalized_url, reason, scope in scheduler.skipped_urls:
                try:
                    await self._ignore_service.log_skip(
                        self.crawl_job_id,
                        url,
                        normalized_url,
                        reason,
                        scope,
                    )
                except Exception as skip_exc:  # noqa: BLE001
                    logger.warning(
                        "Failed to persist skip record for %s: %s",
                        url, skip_exc,
                    )
            await self.db.commit()

        duration_ms = int((time.time() - start_time) * 1000)
        await self._mark_completed(duration_ms)

        await self.event_bus.emit(
            CrawlPipelineEvent.SCHEDULER_COMPLETE,
            audit_id=str(self.crawl_job_id),
            pages_crawled=pages_crawled_count,
            pages_discovered=pages_discovered_count,
            duration_ms=duration_ms,
        )

        pages_failed_count = getattr(scheduler, "pages_failed_count", 0)
        url_diagnostics = scheduler.url_diagnostics if hasattr(scheduler, "url_diagnostics") else {}
        

        logger.info(
            "Crawl completed: %s — pages_crawled=%d, pages_discovered=%d, pages_failed=%d, duration=%dms",
            start_url,
            pages_crawled_count,
            pages_discovered_count,
            getattr(scheduler, 'pages_failed_count', 0),
            duration_ms,
        )
        if url_diagnostics:
            logger.info("URL diagnostics: %s", url_diagnostics)

        return {
            "status": "completed",
            "audit_id": str(self.crawl_job_id),
            "pages_crawled": pages_crawled_count,
            "pages_discovered": pages_discovered_count,
            "pages_skipped": getattr(scheduler, 'pages_skipped_count', 0),
            "pages_failed": getattr(scheduler, 'pages_failed_count', 0),
            "url_diagnostics": url_diagnostics,
        }

    async def crawl_page(
        self,
        url: str,
        depth: int = 0,
        parent_page_id: Optional[UUID] = None,
    ) -> None:
        """
        Crawl a single page and process it.

        Kept for backward compatibility with test-crawler endpoint.
        """
        await self._crawl_page(
            DiscoveredURL(
                url=url,
                normalized_url=normalize_url(url),
                source_url=url,
                source_type="seed",
                depth=depth,
                parent_page_id=parent_page_id,
            ),
            http_sem=asyncio.Semaphore(self.config.http_concurrency if self.config else 10),
            browser_sem=asyncio.Semaphore(self.config.browser_concurrency if self.config else 3),
        )

    async def _crawl_page(self, item: DiscoveredURL, http_sem: asyncio.Semaphore, browser_sem: asyncio.Semaphore) -> None:
        await self.event_bus.emit(
            CrawlPipelineEvent.PAGE_START,
            url=item.normalized_url,
            depth=item.depth,
            parent_page_id=str(item.parent_page_id) if item.parent_page_id else None,
        )

        async with http_sem:
            crawl_result = await self.page_crawl_service.crawl_page(
                item.normalized_url,
                timeout=self.config.request_timeout if self.config else 30,
                follow_redirects=True,
                user_agent=self.config.user_agent if self.config else None,
            )

        await self.event_bus.emit(
            CrawlPipelineEvent.PAGE_FETCHED,
            url=item.normalized_url,
            success=crawl_result.success,
            error=crawl_result.error,
        )

        if crawl_result.error:
            async with async_session_factory() as worker_db:
                logger.debug(
                    "Crawler worker session: url=%s session=%s",
                    item.normalized_url[:80],
                    id(worker_db),
                )
                worker_persistence = self._create_worker_persistence(worker_db)
                await worker_persistence.persist_error(
                    page_id=item.parent_page_id,
                    error_type=crawl_result.error_type or "crawl_error",
                    error_message=crawl_result.error,
                )
                await worker_db.commit()
            await self.event_bus.emit(
                CrawlPipelineEvent.PAGE_ERROR,
                url=item.normalized_url,
                error=crawl_result.error,
            )
            logger.warning("Page crawl failed: %s — error=%s", item.normalized_url, crawl_result.error)
            return False

        document = crawl_result.document
        fetch_result = crawl_result.fetch_result
        normalized_url = crawl_result.normalized_url

        # Redirect-aware: resolve all processing against the effective (final)
        # URL so that relative links are resolved against the post-redirect
        # host/path rather than the originally requested URL.
        effective_url = fetch_result.final_url or normalized_url
        try:
            effective_url = normalize_url(effective_url)
        except Exception:
            effective_url = normalized_url

        # Update the scheduler's base host from the effective URL so that
        # subsequent child URLs are classified against the correct site
        # (handles apex <-> www and HTTP -> HTTPS redirects).
        # A redirect to an *unrelated* host must NOT expand the crawl scope.
        if self._scheduler is not None:
            effective_host = urlparse(effective_url).hostname or ""
            current_base = self._scheduler.base_domain
            if current_base and not is_same_site(effective_host, current_base):
                logger.warning(
                    "Redirect to unrelated host %s — base domain stays %s",
                    effective_host,
                    current_base,
                )
            else:
                self._scheduler.set_base_domain_from_url(effective_url)

        from app.modules.parser.services.parser_orchestrator import ParserOrchestrator
        from app.modules.crawler.utils.thread_pool import cpu_bound_executor
        from functools import partial

        parser = ParserOrchestrator()
        loop = asyncio.get_running_loop()
        parsed = await loop.run_in_executor(
            cpu_bound_executor,
            partial(parser.parse, html=document.raw_html, url=effective_url),
        )

        page_facts = self.page_extraction_service.extract_from_parsed(
            parsed_document=parsed,
            status_code=fetch_result.status_code,
            headers=fetch_result.headers,
            content_length=len(document.raw_html),
            response_time_ms=fetch_result.response_time_ms,
            redirects=[
                {"url": r.url, "status_code": r.status_code}
                for r in fetch_result.redirect_chain
            ],
        )

        if parsed.content and parsed.content.text:
            page_facts.content.content_hash = hashlib.md5(parsed.content.text.encode()).hexdigest()
            page_facts.content.sentence_count = max(
                page_facts.content.sentence_count,
                len([s for s in parsed.content.text.replace("!", ".").replace("?", ".").split(".") if s.strip()])
            )

        link_analysis = self.link_analysis_service(effective_url)
        link_result = await link_analysis.analyze(page_facts.links)

        redirect_chain = fetch_result.redirect_chain

        technical_analysis = self.technical_analysis_service()
        technical_result = await technical_analysis.analyze(
            page_facts.technical,
            content_bytes=fetch_result.content,
            url=effective_url,
        )

        parsed_url = urlparse(normalized_url)
        url_hash = hashlib.md5(normalized_url.encode()).hexdigest()

        page = CrawlPage(
            audit_id=self.crawl_job_id,
            url=item.url,
            normalized_url=normalized_url,
            url_hash=url_hash,
            scheme=parsed_url.scheme,
            host=parsed_url.netloc,
            path=parsed_url.path,
            query=parsed_url.query,
            final_url=fetch_result.final_url,
            depth=item.depth,
            status_code=technical_result.status_code,
            content_type=technical_result.content_type,
            content_length=technical_result.content_length,
            response_time_ms=technical_result.response_time_ms,
            parent_page_id=item.parent_page_id,
            is_crawled=True,
            is_success=200 <= technical_result.status_code < 400,
            is_redirect=len(redirect_chain) > 0,
            is_error=technical_result.status_code >= 400,
        )
        # ---- Persist: each page gets its own session so concurrent
        # workers never share an AsyncSession ----
        async with async_session_factory() as worker_db:
            logger.debug(
                "Crawler worker session: url=%s session=%s",
                item.normalized_url[:80],
                id(worker_db),
            )
            worker_persistence = self._create_worker_persistence(worker_db)
            redirect_service = RedirectService(worker_db, page.id)

            page = await worker_persistence.persist_page(page)

            await worker_persistence.persist_snapshot(
                page.id,
                document.raw_html,
                parsed_data=parsed.model_dump(mode="json"),
            )

            await worker_persistence.buffer_network(
                network_data=PageNetworkData(
                    page_id=page.id,
                    status_code=technical_result.status_code,
                    content_type=technical_result.content_type,
                    content_length=technical_result.content_length,
                    response_time_ms=technical_result.response_time_ms,
                    headers=technical_result.headers,
                    redirects=technical_result.redirects,
                    security=technical_result.security,
                    performance=technical_result.performance,
                )
            )

            page_metadata = {
                "title": page_facts.metadata.title,
                "meta_description": page_facts.metadata.meta_description,
                "canonical": page_facts.metadata.canonical,
                "robots_meta": page_facts.metadata.robots_meta,
                "googlebot": page_facts.metadata.googlebot,
                "viewport": page_facts.metadata.viewport,
                "keywords": page_facts.metadata.keywords,
                "author": page_facts.metadata.author,
                "theme_color": page_facts.metadata.theme_color,
                "charset": page_facts.metadata.charset,
                "favicon": page_facts.metadata.favicon,
                "open_graph": page_facts.metadata.open_graph or {},
                "twitter": page_facts.metadata.twitter or {},
                "meta_tags": page_facts.metadata.meta_tags or [],
                "hreflang": [
                    {"url": h.get("url", ""), "hreflang": h.get("hreflang", "")}
                    for h in (page_facts.metadata.hreflang or [])
                ],
            }

            await worker_persistence.buffer_seo(
                seo_data=PageSEOData(
                    page_id=page.id,
                    title=page_facts.metadata.title,
                    title_length=page_facts.metadata.title_length,
                    meta_description=page_facts.metadata.meta_description,
                    meta_description_length=page_facts.metadata.meta_description_length,
                    canonical=page_facts.metadata.canonical,
                    robots_meta=page_facts.metadata.robots_meta,
                    language=document.language,
                    charset=page_facts.metadata.charset or document.charset,
                    viewport=page_facts.metadata.viewport,
                    favicon=page_facts.metadata.favicon,
                    word_count=page_facts.content.word_count,
                    content_hash=page_facts.content.content_hash,
                    headings=page_facts.content.headings,
                    content={
                        "text": page_facts.content.text,
                        "word_count": page_facts.content.word_count,
                        "character_count": len(page_facts.content.text),
                        "paragraph_count": page_facts.content.paragraph_count,
                        "sentence_count": page_facts.content.sentence_count,
                        "language": document.language,
                        "content_hash": page_facts.content.content_hash,
                    },
                    structured_data={
                        "exists": len(technical_result.json_ld) > 0,
                        "items": technical_result.json_ld,
                        "types": [lk.get("type") for lk in technical_result.json_ld],
                    },
                    social={
                        "open_graph": page_facts.metadata.open_graph,
                        "twitter": page_facts.metadata.twitter,
                    },
                    indexability={
                        "robots_meta": page_facts.metadata.robots_meta,
                        "canonical": page_facts.metadata.canonical,
                    },
                    accessibility=technical_result.accessibility,
                    page_metadata=page_metadata,
                )
            )

            await worker_persistence.buffer_resources(page.id, page_facts.resources.resources, page_url=effective_url)
            await worker_persistence.buffer_links(page.id, link_result.links)

            redirect_links = link_result.redirect_links
            if redirect_links:
                await redirect_service.process_and_save_redirects(redirect_links)

            if document.is_html:
                self._enqueue_links(link_result.links, page.id, effective_url, item.depth)

            await self.event_bus.emit(
                CrawlPipelineEvent.PAGE_PERSISTED,
                url=item.normalized_url,
                page_id=str(page.id),
            )

            # Flush buffered data into the session, then update progress
            # (which commits).  flush_all before commit ensures buffered
            # items are not lost when the session closes.
            await worker_persistence.flush_all()
            await self._update_progress(
                getattr(self._scheduler, "pages_crawled_count", 0) + 1,
                persistence=worker_persistence,
            )


    async def get_summary(self) -> Optional[dict]:
        """Get crawl summary."""
        return {"status": "completed", "audit_id": str(self.crawl_job_id)}

    # -- private helpers ----------------------------------------------

    def _create_worker_persistence(self, db) -> CrawlPersistenceService:
        """Create a worker-local persistence service bound to *db*.

        Each concurrent _crawl_page call gets its own AsyncSession and its
        own CrawlPersistenceService instance so buffers and transactions
        never cross worker boundaries.
        """
        persistence = CrawlPersistenceService(db, self.crawl_job_id)
        flush_every = getattr(self.config, "write_buffer_flush_every", 20) if self.config else 20
        persistence.set_flush_every(flush_every)
        return persistence

    async def _update_progress(self, current_page: int, persistence: Optional[CrawlPersistenceService] = None) -> None:
        """Update crawl job progress fields and report to subscribers.

        When *persistence* is provided (worker context), that worker-local
        service is used instead of the orchestrator's shared one.  This keeps
        progress commits on the worker's own AsyncSession.
        """
        total = self.config.max_pages if self.config else None
        discovered = getattr(self._scheduler, "pages_discovered_count", None)
        svc = persistence or self.persistence
        try:
            if discovered is not None:
                await svc.update_progress(current_page, total, pages_discovered=discovered)
            else:
                await svc.update_progress(current_page, total)
        except Exception as exc:
            logger.warning(f"_update_progress: {exc}", exc_info=True)
        if self._progress_callback:
            self._progress_callback(current_page, total)

    async def _mark_running(self) -> None:
        await self._set_status("crawling")

    async def _mark_completed(self, duration_ms: int) -> None:
        await self._finalize_status("completed", duration_ms)

    async def _mark_failed(self, error_message: str) -> None:
        job = await self.job_repository.get_by_id(self.crawl_job_id)
        if job and job.status not in ("completed", "failed", "cancelled"):
            job.status = "failed"
            job.error = error_message[:1024]
            job.completed_at = utc_now()
            job.progress_percent = 100
            await self.job_repository.update(job)
            if self.db:
                await self.db.commit()
            if self._progress_callback:
                self._progress_callback(
                    job.current_page or 0,
                    job.total_pages,
                )

    async def _set_status(self, status: str) -> None:
        job = await self.job_repository.get_by_id(self.crawl_job_id)
        if job:
            if status == "crawling" and not job.started_at:
                job.started_at = utc_now()
            job.status = status
            await self.job_repository.update(job)
            if self.db:
                await self.db.commit()

    async def _finalize_status(self, status: str, duration_ms: int) -> None:
        job = await self.job_repository.get_by_id(self.crawl_job_id)
        if job:
            job.status = status
            job.completed_at = utc_now()
            job.duration_ms = duration_ms
            job.progress_percent = 100
            if job.total_pages:
                job.current_page = job.total_pages
            await self.job_repository.update(job)
            if self.db:
                await self.db.commit()
            if self._progress_callback:
                self._progress_callback(job.total_pages or 0, job.total_pages)

    def _enqueue_links(
        self,
        links: list,
        page_id: UUID,
        page_url: str,
        depth: int,
    ) -> None:
        if not self._scheduler or not self.config:
            return

        next_depth = depth + 1
        max_depth = self.config.max_depth

        for link in links:
            if next_depth > max_depth:
                continue
            if link.get("is_internal"):
                raw_url = link["url"]
                clean_url = strip_tracking_params(raw_url)
                if (
                    self._restrict_to_preselected
                    and self._preselected_urls is not None
                    and normalize_url(clean_url) not in self._preselected_urls
                ):
                    continue
                submitted = self._scheduler.submit_discovered_url(
                    url=clean_url,
                    source_url=page_url,
                    source_type="html_link",
                    depth=next_depth,
                    parent_page_id=page_id,
                )
                if submitted:
                    logger.debug(
                        "URL queued [html_link]: %s (depth=%d, source=%s)",
                        clean_url,
                        next_depth,
                        page_url,
                    )
                else:
                    logger.debug(
                        "URL rejected [html_link]: %s (depth=%d, source=%s)",
                        clean_url,
                        next_depth,
                        page_url,
                    )

