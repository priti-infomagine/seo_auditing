"""
Health routes package.
"""